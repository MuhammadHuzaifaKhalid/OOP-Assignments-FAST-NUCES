#include <iostream>

using namespace std;

int string_length(string str) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

void string_copy(char* dest, const char* src, int length) 
{
    for (int i = 0; i < length; ++i) {
        dest[i] = src[i];
    }
    dest[length] = '\0';
}

void count_characters(const char* str, int* charCount, int length) 
{
    for (int i = 0; i < length; ++i) {
        charCount[str[i]]++;
    }
}

char* string_converter(const string& str) 
{
    int len = string_length(str);
    char* charArray = new char[len + 1];
    for (int i = 0; i < len; ++i) {
        charArray[i] = str[i];
    }
    charArray[len] = '\0';
    return charArray;
}

char* find_smallest_substring(const char* s, const char* t, int lenS, int lenT, int k) {
    if (k > lenS) 
    {
        return nullptr;
    }

    int minLen = lenS + 1;
    char* minSubstring = new char[lenS + 1];
    *minSubstring = '\0';

    int* charCountT = new int[256]();
    int* charCountWindow = new int[256]();

    count_characters(t, charCountT, lenT);

    int start = 0;
    int count = 0;

    for (int end = 0; end < lenS; ++end) {
        (*(charCountWindow + *(s + end)))++;

        if (*(charCountWindow + *(s + end)) <= *(charCountT + *(s + end))) {
            count++;
        }

        if (count == lenT) {
            while (*(charCountWindow + *(s + start)) > *(charCountT + *(s + start)) || *(charCountT + *(s + start)) == 0) {
                if (*(charCountWindow + *(s + start)) > *(charCountT + *(s + start))) {
                    (*(charCountWindow + *(s + start)))--;
                }
                start++;
            }

            int windowLen = end - start + 1;
            if (windowLen < minLen) {
                minLen = windowLen;
                string_copy(minSubstring, s + start, windowLen);
            }
        }
    }

    delete[] charCountT;
    delete[] charCountWindow;

    if (minLen == lenS + 1) {
        delete[] minSubstring;
        return nullptr;
    }

    return minSubstring;
}

char* smallest_substring_with_k_occurrences(const char* s, const char* t, int k) {
    int lenS = string_length(s);
    int lenT = string_length(t);
    return find_smallest_substring(s, t, lenS, lenT, k);
}

int main() {
    string s, t;
    int k;
    cout << "Enter a string: ";
    cin >> s;
    cout << "Enter substring: ";
    cin >> t;
    cout << "Enter k: ";
    cin >> k;

    char* cs = string_converter(s);
    char* ct = string_converter(t);

    char* result = smallest_substring_with_k_occurrences(cs, ct, k);
    if (result) 
    {
        cout << "Smallest substring: " << result << endl;
        delete[] result;
    } 
    else
    {
        cout << "No valid substring found." << endl;
    }

    delete[] cs;
    delete[] ct;

    return 0;
}

#include<iostream>
using namespace std;

int MaxProfit(int *prices, int size);

int main()
{
    int input;
    cout << "Enter size of array: ";
    cin >> input;

    int *prices = new int[input];

    for(int i = 0; i < input; i++)
    {
        cout << "Enter price for day " << i + 1 << " : ";
        cin >> prices[i];
    }

    cout << endl << "THE PRICES ARE: " << endl;
    for(int i = 0; i < input; i++)
    {
        cout << prices[i] << "\t";
    }
    cout << endl;

    int buyDay = -1, sellDay = -1;
    int temp_buy_day = 0;
    int profit = 0;
    int current_profit = 0;

    for (int i = 1; i < input; i++) 
    {
        int diff = prices[i] - prices[i - 1];
        if (diff > 0) 
        {
            if (current_profit == 0) 
            {
                buyDay = temp_buy_day;
            }
            current_profit += diff;
            sellDay = i;
        }
        else 
        {
            temp_buy_day = i;
            profit += current_profit;
            current_profit = 0;
        }
    }
    profit += current_profit;

    cout<<endl<< "Maximum profit: " << profit << endl;
    if (buyDay != -1 && sellDay != -1)
    {
        cout << "Buy on day: " << buyDay + 1 << endl;
        cout << "Sell on day: " << sellDay + 1 << endl;
    }

    delete[] prices; // Free the memory

    return 0;
}

int MaxProfit(int prices[], int n) 
{
    if (n <= 1) 
    {
        return 0;
    }

    int profit = 0;
    for (int i = 1; i < n; i++) 
    {
        int diff = prices[i] - prices[i - 1];
        if (diff > 0) 
        {
            profit += diff;
        }
    }

    return profit;
}

#include <iostream>
#include <string>
#include <ctime>
using namespace std;

class RentalReservation {
	string reservation_id;
	string customer_name;
	string* car_make_model;
	int totalmodelavailable;
	int rentedcar;
	float* rental_rate;
	float rental_total;
	string pickup_date;
	string return_date;
	int rental_duration;
	string additional_services;
	int  customer_age;
	bool gps;
    bool insurance;
    bool baby_seat;
	int duration();
	bool dateandtime(string date);
	int intoint(string temp, int from, int to);
public:
	RentalReservation();
	void addmodel(string add);
	void getReservationDetails();
	void doReservations();
	int calculateRentalTotal();
	void updatereservations();
	void chooseAdditionalServices();
	~RentalReservation();
};
bool RentalReservation::dateandtime(string date)
{
	bool checkdate = true;
	bool checkmonth = true;
	bool checkyear = true;
	bool checktime = true;

	for (int i = 0; i < 2; i++) {
		if (date[i] >= '0' && date[i] <= '9') {}

		else {
			checkdate = false;
		}
	}
	if (!checkdate) {
		cout << "Your Date formate is not right" << endl;
	}

	for (int i = 3; i < 5; i++) {
		if (date[i] >= '0' && date[i] <= '9' && date[2] == '-') {}

		else {
			checkmonth = false;
		}
	}
	if (!checkmonth) {
		cout << "Your Month format is not right" << endl;
	}

	for (int i = 6; i < 10; i++) {
		if (date[i] >= '0' && date[i] <= '9' && date[5] == '-') {}

		else {
			checkyear = false;
		}
	}
	if (!checkyear) {
		cout << "Your year format is not right" << endl;
	}

	for (int i = 11; i < 13; i++) {
		if (date[i] >= '0' && date[i] <= '9' && date[10] == ':') {}

		else {
			checktime = false;
		}
	}
	if (!checktime) {
		cout << "Your time format is not right" << endl;
	}

	if (checkdate && checkmonth && checkyear && checktime) {
		return true;
	}
	else {
		return false;
	}
}

int RentalReservation::intoint(string temp, int from, int to)
{
	int n = 0;
	int result = 0;
	for (int i = from; i < to; i++) {
		int n = temp[i] - '0';
		result = result * 10 + n;
	}
	return result;
}

int RentalReservation::duration()
{
	int  pdate = 0;
	int pmonth = 0;
	int pyear = 0;
	int ptime = 0;

	pdate = intoint(this->pickup_date, 0, 2);
	pmonth = intoint(this->pickup_date, 3, 5);
	pyear = intoint(this->pickup_date, 6, 10);
	ptime = intoint(this->pickup_date, 11, 13);

	int  rdate = 0;
	int rmonth = 0;
	int ryear = 0;
	int rtime = 0;
	
	rdate = intoint(this->return_date, 0, 2);
	rmonth = intoint(this->return_date, 3, 5);
	ryear = intoint(this->return_date, 6, 10);
	rtime = intoint(this->return_date, 11, 13);

	int  ddate = rdate - pdate;
	int dmonth = rmonth - pmonth;
	int dyear = ryear - pyear;
	int dtime = rtime - ptime;

	// Returns per hour duration of rent

	if (dyear == 0 && dmonth == 0 && ddate == 0 && dtime > 0) {
		return dtime;
	}

	else if (dyear == 0 && dmonth == 0 && ddate > 0) {
		ddate *= 24;
		ddate = ddate + dtime;
		return ddate;
	}

	else if (dyear == 0 && dmonth > 0) {
		dmonth *= 30;
		dmonth *= 24;
		ddate *= 24;
		dmonth = dmonth + ddate + dtime;
		return dmonth;
	}

	else if (dyear >0) {
		dyear *= 365;
		dyear *= 24;
		dmonth *= 30;
		dmonth *= 24;
		ddate *= 24;
		dmonth = dyear + dmonth + ddate + dtime;
		return dyear;
	}

	return 0;
}

RentalReservation::RentalReservation()
{
	this->car_make_model = new string[5];
	this->car_make_model[0] = "Honda City_2020";
	this->car_make_model[1] = "Suzuki Alto_2024";
	this->car_make_model[2] = "Toyota Yaris_2021";
	this->car_make_model[3] = "Honda Civic_2019";
	this->car_make_model[4] = "Suzuki Wagon R_2022";

	this->rental_rate = new float[5];
	this->rental_rate[0] = 200;
	this->rental_rate[1] = 180;
	this->rental_rate[2] = 250;
	this->rental_rate[3] = 210;
	this->rental_rate[4] = 190;

	this->customer_name = "";
	this->customer_age = 0;
	this->additional_services = "";
	this->pickup_date = "";
	this->return_date = "";
	this->rental_duration = 0;
	this->rental_total = 0;
	this->rentedcar = 0;
	this->totalmodelavailable = 5;
	this->gps=false;
	this->baby_seat=false;
	this->insurance=false;


	srand(time(0));

	string date;
	char* temp = new char[14];
	for (int i = 0; i < 10; i++) {
		if (i < 4) {
			temp[i] = rand() % 26 + 65;
		}
		else if (i < 8 && i >= 4) {
			temp[i] = rand() % 26 + 97;
		}
		else if (i >= 8 && i < 10) {
			temp[i] = rand() % 15 + 32;
		}
	}

	bool b = false;
	while (!b) {
		for (int i = 10; i < 14; i++) {
			temp[i] = rand() % 9 + 48;
		}
		if ((temp[10] - '0') + (temp[11] - '0') + (temp[12] - '0') + (temp[13] - '0') <= 18) {
			b = true;
		}
		else {
			b = false;
		}
	}

	for (int i = 0; i < 14; i++) {
		date += temp[i];
	}

	delete[] temp;
	this->reservation_id = date;
}

void RentalReservation::doReservations()
{
	cout << "********** Welcome **********\nFor reservations fill the following form: \n" << endl;
	string name, id;
	int age;
	string pickdate = "";
	string retdate = "";

	cout << "Enter Your Name: " << endl;
	getline(cin, this->customer_name);

	cout << "Enter your age: " << endl;
	cin >> age;
	this->customer_age = age;

	cout << "Select Model" << endl;
	for (int i = 0; i < this->totalmodelavailable; i++) {
		cout << i + 1 << "- " << this->car_make_model[i] << endl;
	}
	cin >> this->rentedcar;

	this->chooseAdditionalServices();

	bool check = false;
	cout << "Enter Pick-up date (Format: date-month-year:time e.g 03-02-2023:14) " << endl;
	while (!check) {
		cin >> pickdate;
		check = dateandtime(pickdate);
	}
	this->pickup_date = pickdate;

	check = false;
	cout << "Enter return date (Format: date-month-year:time e.g 23-12-2023:14) " << endl;
	while (!check) {
		cin >> retdate;
		check = dateandtime(retdate);
	}
	this->return_date = retdate;

	
}

void RentalReservation::addmodel(string add)
{
	int count = this->totalmodelavailable;

	string* temp = new string[count + 1];
	for (int i = 0; i < count; i++) {
		temp[i] = this->car_make_model[i];
	}
	temp[count] = add;
	delete[] this->car_make_model;
	this->car_make_model = temp;

	//Price For new model
	float* temp2 = new float[count + 1];
	for (int i = 0; i < count; i++) {
		temp2[i] = this->rental_rate[i];
	}

	srand(time(0));
	int m = rand() % 5;
	temp2[count] = this->rental_rate[m] - 10;
	delete[] this->rental_rate;
	this->rental_rate = temp2;


	this->totalmodelavailable += 1;

	
}

int RentalReservation::calculateRentalTotal() {
    this->rental_duration = duration();

    float base_rate = this->rental_rate[this->rentedcar - 1]; // Correct the index
    float total = base_rate * this->rental_duration;

    if (this->customer_age >= 30 && this->customer_age < 50) {
        total += 5000;
    }
    else if (this->customer_age >= 50) {
        total += 7000;
    }

    if (gps) {
        total += this->rental_duration * 10;
    }
    if (insurance) {
        total += this->rental_duration * 20;
    }
    if (baby_seat) {
        total += this->rental_duration * 15;
    }

    this->rental_total = total; // Store the calculated total
    return total;
}

void RentalReservation::chooseAdditionalServices() {
    char choice;
    cout << "Would you like to add GPS to your reservation? Rs 10 per hour (y/n): ";
    cin >> choice;
    gps = (choice == 'y' || choice == 'Y');

    cout << "Would you like to add insurance to your reservation? Rs 20 per hour (y/n): ";
    cin >> choice;
    insurance = (choice == 'y' || choice == 'Y');

    cout << "Would you like to add a baby seat to your reservation? Rs 15 per hour (y/n): ";
    cin >> choice;
    baby_seat = (choice == 'y' || choice == 'Y');
}

void RentalReservation::updatereservations()
{
	int m = 0;
	cout << "Do You want to update reservation? (Press 1 for yes/ Press 2 for NO)" << endl;
	cin >> m;
	while (m != 2) {

		int n = 0;
		cout << "What do you want to update: \n1- Customer Name\n2- Customer Age\n3- Car Model\n4- Pick-up date\n5- Return Date" << endl;
		cin >> n;

		switch (n) {
		case(1): {
			cout << "Enter Updated Name: " << endl;
			cin.ignore();
			getline(cin, this->customer_name);
			break;
		}
		case(2): {
			cout << "Enter Updated age: " << endl;
			cin >> this->customer_age;
			break;
		}
		case(3): {
			cout << "Select Model: " << endl;
			for (int i = 0; i < this->totalmodelavailable; i++) {
				cout << i + 1 << "- " << this->car_make_model[i] << endl;
			}
			cin >> this->rentedcar;
			break;
		}
		case(4): {
			bool check = false;
			cout << "Enter Pick-up date (Format: date-month-year:time e.g 03-02-2023:14) " << endl;
			while (!check) {
				cin >> this->pickup_date;
				check = dateandtime(this->pickup_date);
			}
			break;
		}
		case(5): {
			bool check = false;
			cout << "Enter Return date (Format: date-month-year:time e.g 03-02-2023:14) " << endl;
			while (!check) {
				cin >> this->return_date;
				check = dateandtime(this->return_date);
			}
			break;
		}
		default: {
			cout << "Invalid Input :)" << endl;
		}
		}

		getReservationDetails();

		cout << "Do You want to update reservation? (Press 1 for yes/ Press 2 for NO)" << endl;
		cin >> m;
	}
}

void RentalReservation::getReservationDetails() {
    cout<<endl<<endl<< "******* Your Reservation details *******" <<endl<< endl;
    cout<<"Reservation ID "<<this->reservation_id<<endl;
    cout << "Name: " << this->customer_name << endl;
    cout << "Age: " << this->customer_age << endl;
    cout << "Car Model: " << this->car_make_model[this->rentedcar - 1] << endl;
    cout << "Pickup Date: " << this->pickup_date << endl;
    cout << "Return Date: " << this->return_date << endl;
    cout<<"Rent Rate per hour: " << this->rental_rate[this->rentedcar - 1]<<endl;
    //cout<<"Rental Total: Rs" << this->rental_total << endl;
    cout << "Additional Services: " << endl;
    if (gps) cout << " - GPS" << endl;
    if (insurance) cout << " - Insurance" << endl;
    if (baby_seat) cout << " - Baby Seat" << endl;
    if (!gps && !insurance && !baby_seat) cout << " - None" << endl;
    cout << "Rental Duration: " << this->rental_duration << " hours" << endl;
    cout << "Rental Total: Rs" << calculateRentalTotal() << endl;
}

RentalReservation::~RentalReservation()
{
	delete[] this->car_make_model;
	this->car_make_model = nullptr;
	delete[] this->rental_rate;
	this->rental_rate = nullptr;
	cout << "\n\nThe object has been destroyed successfully " << endl;
}

int main() {

	RentalReservation R1;
	R1.addmodel("Toyota Vitz_2022");
	R1.doReservations();
	R1.getReservationDetails();
	R1.addmodel("Suzuki Mehran_2023");
	R1.updatereservations();

	return 0;
}

#include<iostream>
using namespace std;

void printTop(int step);
void printMiddle(int step);
void printBottom(int step);

void printTop(int step) {
    if (step > 4) {
        printMiddle(5);
        return;
    }
    switch(step) {
        case 0:
        case 1:
            cout << "         |:      :|" << endl;
            break;
        case 2:
            cout << "         |:______:|" << endl;
            break;
        case 3:
            cout << "         (=______=)" << endl;
            break;
        case 4:
            cout << "        /. \' 12 \' .\\" << endl;
            break;
    }
    printTop(step + 1);
}

void printMiddle(int step) {
    if (step > 9) {
        printBottom(10);
        return;
    }
    switch(step) {
        case 5:
            cout << "       /.          .\\" << endl;
            break;
        case 6:
            cout << "      ||      |     ||  " << endl;
            break;
        case 7:
            cout << "      ||9     .    3||" << endl;
            break;
        case 8:
            cout << "      ||       \\    ||" << endl;
            break;
        case 9:
            cout << "       \\\\          //" << endl;
            break;
    }
    printMiddle(step + 1);
}

void printBottom(int step) {
    if (step > 14) {
        return;
    }
    switch(step) {
        case 10:
            cout << "        \\\'._ 6 _. \'/" << endl;
            break;
        case 11:
            cout << "         (=______=)" << endl;
            break;
        case 12:
        case 13:
        case 14:
            cout << "         |:      :|" << endl;
            break;
    }
    printBottom(step + 1);
}

int main() {
    printTop(0);
    return 0;
}

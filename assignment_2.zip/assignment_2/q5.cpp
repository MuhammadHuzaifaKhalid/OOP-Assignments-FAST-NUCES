#include<iostream>
using namespace std;

class bignumber {
	string strnum;
	long long longnum;
public:
	bignumber(string number);
	bignumber(long long number);
	bignumber add(bignumber other);
	bignumber subtract(bignumber other);
	bignumber multiply(bignumber other);
	bignumber divide(bignumber other);
	bignumber pow(int other);
	bool equals(const bignumber& other);
	bool equals(const long long& other);
	bool equals(const string& other);
	bool isNegative()const;
	bool isPositive();
	bool isEven();
	bool isOdd();
	bignumber abs()const;
	string getstring();
	bignumber setstring(const string& newstr);
	bignumber trimleadingzeos();
	/*
	bignumber negate();
	*/
	void display();
	
};

bignumber::bignumber(string number)
{
	this->strnum = number;
	this->longnum = 0;
}

bignumber::bignumber(long long number)
{
	this->longnum = number;
	this->strnum = "";
}

bignumber bignumber::add(bignumber other)
{
	int num1 = 0;
	int num2 = 0;
	int* temp1 = new int[0];
	int* temp2 = new int[0];

	if (other.strnum[0] == '-') {
		int* temp1 = new int[other.strnum.length()-1];
		for (int i = 1; i < other.strnum.length(); i++) {
			temp1[i-1] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length()-1; i++) {
			num1 = num1 * 10 + temp1[i];
		}
		
		num1 *= -1;
	}

	else {
		int* temp1 = new int[other.strnum.length()];
		for (int i = 0; i < other.strnum.length(); i++) {
			temp1[i] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length(); i++) {
			num1 = num1 * 10 + temp1[i];
		}
	}

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length()-1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i-1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length()-1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

    int result = num1 + num2;

	bool isNegative = false;
	if (result < 0) {
		result *= -1;
		isNegative = true;
	}

	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	if (isNegative) {
		string neg = "-";
		answer = neg + answer;
	}

    delete[] temp1;
    delete[] temp2;
    delete[] resultarr;

    return bignumber(answer);
}

bignumber bignumber::subtract(bignumber other)
{
	int num1 = 0;
	int num2 = 0;
	int* temp1 = new int[0];
	int* temp2 = new int[0];

	if (other.strnum[0] == '-') {
		int* temp1 = new int[other.strnum.length() - 1];
		for (int i = 1; i < other.strnum.length(); i++) {
			temp1[i - 1] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length() - 1; i++) {
			num1 = num1 * 10 + temp1[i];
		}

		num1 *= -1;
	}

	else {
		int* temp1 = new int[other.strnum.length()];
		for (int i = 0; i < other.strnum.length(); i++) {
			temp1[i] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length(); i++) {
			num1 = num1 * 10 + temp1[i];
		}
	}

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

	int result = num2 - num1;

	bool isNegative = false;
	if (result < 0) {
		result *= -1;
		isNegative = true;
	}

	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	if (isNegative) {
		string neg = "-";
		answer = neg + answer;
	}

	delete[] temp1;
	delete[] temp2;
	delete[] resultarr;

	return bignumber(answer);
}

bignumber bignumber::multiply(bignumber other)
{
	int num1 = 0;
	int num2 = 0;
	int* temp1 = new int[0];
	int* temp2 = new int[0];

	if (other.strnum[0] == '-') {
		int* temp1 = new int[other.strnum.length() - 1];
		for (int i = 1; i < other.strnum.length(); i++) {
			temp1[i - 1] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length() - 1; i++) {
			num1 = num1 * 10 + temp1[i];
		}

		num1 *= -1;
	}

	else {
		int* temp1 = new int[other.strnum.length()];
		for (int i = 0; i < other.strnum.length(); i++) {
			temp1[i] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length(); i++) {
			num1 = num1 * 10 + temp1[i];
		}
	}

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

	int result = num1 * num2;

	bool isNegative = false;
	if (result < 0) {
		result *= -1;
		isNegative = true;
	}

	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	if (isNegative) {
		string neg = "-";
		answer = neg + answer;
	}

	delete[] temp1;
	delete[] temp2;
	delete[] resultarr;

	return bignumber(answer);
}

bignumber bignumber::divide(bignumber other)
{
	int num1 = 0;
	int num2 = 0;
	int* temp1 = new int[0];
	int* temp2 = new int[0];

	if (other.strnum[0] == '-') {
		int* temp1 = new int[other.strnum.length() - 1];
		for (int i = 1; i < other.strnum.length(); i++) {
			temp1[i - 1] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length() - 1; i++) {
			num1 = num1 * 10 + temp1[i];
		}

		num1 *= -1;
	}

	else {
		int* temp1 = new int[other.strnum.length()];
		for (int i = 0; i < other.strnum.length(); i++) {
			temp1[i] = other.strnum[i] - '0';
		}

		for (int i = 0; i < other.strnum.length(); i++) {
			num1 = num1 * 10 + temp1[i];
		}
	}

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

	int result = num1 / num2;

	bool isNegative = false;
	if (result < 0) {
		result *= -1;
		isNegative = true;
	}

	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	if (isNegative) {
		string neg = "-";
		answer = neg + answer;
	}

	delete[] temp1;
	delete[] temp2;
	delete[] resultarr;

	return bignumber(answer);
}

bignumber bignumber::pow(int other)
{
	int num2 = 0;
	int* temp2 = new int[0];

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

	int result =  1;

	for (int i = 0; i < other; i++) {
		result *= num2;
	}
	bool isNegative = false;
	if (result < 0) {
		result *= -1;
		isNegative = true;
	}
	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	if (isNegative) {
		string neg = "-";
		answer = neg + answer;
	}

	delete[] temp2;
	delete[] resultarr;

	return bignumber(answer);
}

bool bignumber::equals(const bignumber& other)
{
	if (this->longnum == other.longnum && this->strnum == other.strnum) {
		return true;
	}
	else {
		return false;
	}
}

bool bignumber::equals(const long long& other)
{
	if (this->longnum == other) {
		return true;
	}
	else {
		return false;
	}
}

bool bignumber::equals(const string& other)
{
	if (this->strnum == other) {
		return true;
	}
	else {
		return false;
	}
}

bool bignumber::isNegative() const
{
	if (this->longnum < 0 || this->strnum[0] == '-') {
		return true;
	}
	else {
		return false;
	}
}

bool bignumber::isPositive()
{
	if (this->longnum > 0 || this->strnum[0] != '-') {
		return true;
	}
	else {
		return false;
	}
}

bool bignumber::isEven()
{
	int num2 = 0;
	int* temp2 = new int[0];

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

	delete[] temp2;

	if (this->longnum % 2 == 0 || num2 % 2 == 0) {
		return true;
	}
	else {
		return false;
	}
}

bool bignumber::isOdd()
{
	int num2 = 0;
	int* temp2 = new int[0];

	if (this->strnum[0] == '-') {

		int* temp2 = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp2[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num2 = num2 * 10 + temp2[i];
		}

		num2 *= -1;
	}

	else {
		int* temp2 = new int[this->strnum.length()];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp2[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num2 = num2 * 10 + temp2[i];
		}
	}

	delete[] temp2;

	if (this->longnum % 2 != 0 || num2 % 2 != 0) {
		return true;
	}
	else {
		return false;
	}
}

bignumber bignumber::abs() const
{
	int num = 0;
	if (this->strnum[0] == '-') {

		int* temp = new int[this->strnum.length() - 1];
		for (int i = 1; i < this->strnum.length(); i++) {
			temp[i - 1] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length() - 1; i++) {
			num = num * 10 + temp[i];
		}
	}

	else {
		int* temp = new int[this->strnum.length() ];
		for (int i = 0; i < this->strnum.length(); i++) {
			temp[i] = this->strnum[i] - '0';
		}

		for (int i = 0; i < this->strnum.length(); i++) {
			num = num * 10 + temp[i];
		}
	}


	int result = 0;

	result = num;


	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	delete[] resultarr;

	return bignumber(answer);
}
 
string bignumber::getstring()
{
	return this->strnum;
}

bignumber bignumber::setstring(const string& newstr)
{
	return bignumber(newstr);
}

bignumber bignumber::trimleadingzeos()
{
	int m = 0;
	int num = 0;
	bool isNegative = false;
	if (this->strnum[0] == '-') {
		isNegative = true;
	}
	while (1 > 0) {
		if (this->strnum[m] != '0' && this->strnum[m] != '-') {
			break;
		}
		else {
			m++;
		}
	}

	int* temp = new int[m];
	for (int i = m; i < this->strnum.length(); i++) {
		temp[i] = this->strnum[i] - '0';
	}

	for (int i = m; i < this->strnum.length(); i++) {
		num = num * 10 + temp[i];
	}

	int result = num;

	int tempresult = result;
	int size = 0;
	while (tempresult != 0) {
		tempresult /= 10;
		size++;
	}

	int* resultarr = new int[size];
	tempresult = result;
	for (int i = 0; i < size; i++) {
		resultarr[i] = tempresult % 10;
		tempresult /= 10;
	}

	string answer;
	for (int i = 0; i < size; i++) {
		answer += resultarr[size - i - 1] + '0';
	}

	if (isNegative) {
		string neg = "-";
		answer = neg + answer;
	}

	delete[] resultarr;

	return bignumber(answer);
}

void bignumber::display()
{
	cout << this->strnum << endl;
}

//
//bignumber bignumber::negate()
//{
//	return bignumber();
//}
//

int main() {
	int n;
	string s1,s2;
	cout << "Select:\n1- Addition\n2- Subraction\n3- Multiplication\n4- Division\n5- Power\n6- Triming leading Zeros\n7- Absolute value\n8- Check Equality\n9- Check Polarity" << endl;
	cin >> n;
	cout << endl;
	switch (n) {
	case(1):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		cout << "Enter second number: " << endl;
		cin >> s2;
		bignumber second(s2);
		bignumber result = first.add(second);
		result.display();
		break;
	}

	case(2):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		cout << "Enter second number: " << endl;
		cin >> s2;
		bignumber second(s2);
		bignumber result = first.subtract(second);
		result.display();
		break;
	}

	case(3):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		cout << "Enter second number: " << endl;
		cin >> s2;
		bignumber second(s2);
		bignumber result = first.multiply(second);
		result.display();
		break;
	}

	case(4):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		cout << "Enter second number: " << endl;
		cin >> s2;
		bignumber second(s2);
		bignumber result = first.divide(second);
		result.display();
		break;
	}

	case(5): 
	{
		int pow=0;
		cout << "Enter First Number: " << endl;
		cin >> s1;
		cout << "Enter Power: " << endl;
		cin >> pow;
		bignumber first(s1);
		bignumber result = first.pow(pow);
		result.display();
		break;
	}
	case(6):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		bignumber result = first.trimleadingzeos();
		result.display();
		break;
	}

	case(7):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		bignumber result = first.abs();
		result.display();
		break;
	}

	case(8):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		cout << "Enter second number: " << endl;
		cin >> s2;
		bignumber second(s2);
		if (first.equals(second)) {
			cout << "Both Numbers are equal" << endl;
		}

		else {
			cout << "Numbers are NOT equal" << endl;
		}
		break;
	}

	case(9):
	{
		cout << "Enter First Number: " << endl;
		cin >> s1;
		bignumber first(s1);
		if (first.isNegative()) {
			cout << "Number is negative equal" << endl;
		}
		else if (first.isPositive()) {
			cout << "Number is Positive" << endl;
		}
		break;
	}
	default:
	{
		cout << "Invalid Input :)" << endl;
	}
	}

	return 0;
}

	
#include <iostream>
#include <string>

using namespace std;

struct Account {
    string name;
    int accountNumber;
    int balance;
    string pin;
    
    Account(string n, int accNum, int bal, string p) : name(n), accountNumber(accNum), balance(bal), pin(p) {}
};

class BankSystem {
private:
    Account* accounts[100];
    int numAccounts;
    string adminPin;

public:
    BankSystem() : numAccounts(0), adminPin("4548") {}

    void openAccount() {
        string name, pin;
        int accountNumber = numAccounts + 1;
        int balance = 0;
        cout << "Enter customer name: ";
        cin >> name;
        cout << "Set customer PIN: ";
        cin >> pin;
        accounts[numAccounts++] = new Account(name, accountNumber, balance, pin);
        cout << "Account created successfully. Account number is " << accountNumber << endl;
    }

    void payBill(int accNum, int amount) {
        if (accounts[accNum - 1]->balance >= amount) {
            accounts[accNum - 1]->balance -= amount;
            cout << "Bill paid successfully." << endl;
        } else {
            cout << "Insufficient balance." << endl;
        }
    }

    void depositMoney(int accNum, int amount) {
        accounts[accNum - 1]->balance += amount;
        cout << "Money deposited successfully." << endl;
    }

    void withdrawMoney(int accNum, int amount) {
        if (accounts[accNum - 1]->balance >= amount) {
            accounts[accNum - 1]->balance -= amount;
            cout << "Money withdrawn successfully." << endl;
        } else {
            cout << "Insufficient balance." << endl;
        }
    }

    void viewAccountDetails(int accNum) {
        cout << "Name: " << accounts[accNum - 1]->name << endl;
        cout << "Account Number: " << accounts[accNum - 1]->accountNumber << endl;
        cout << "Balance: " << accounts[accNum - 1]->balance << endl;
    }

    void validatePin(int accNum, string pin) {
        if (accounts[accNum - 1]->pin == pin) {
            cout << "PIN validated successfully." << endl;
        } else {
            cout << "Invalid PIN." << endl;
        }
    }

    void changePin(int accNum, string oldPin, string newPin) {
        if (accounts[accNum - 1]->pin == oldPin) {
            accounts[accNum - 1]->pin = newPin;
            cout << "PIN changed successfully." << endl;
        } else {
            cout << "Invalid old PIN." << endl;
        }
    }

    int getBalance(int accNum, string pin) {
        if (accounts[accNum - 1]->pin == pin) {
            return accounts[accNum - 1]->balance;
        } else {
            cout << "Invalid PIN." << endl;
            return -1; // Return -1
        }
    }

    bool isAdminAuthenticated(string pin) {
        return (pin == adminPin);
    }
};

int main() {
    BankSystem bankSystem;
    char choice;

    do {
        cout << endl << "     **Welcome**" << endl << endl;
        cout << "Please choose an option:" << endl;
        cout << "1. Open Account" << endl;
        cout << "2. Pay Bill" << endl;
        cout << "3. Deposit Money" << endl;
        cout << "4. Withdraw Money" << endl;
        cout << "5. View Account Details" << endl;
        cout << "6. ATM Functions" << endl;
        cout << "7. Admin Functions" << endl;
        cout << "8. Exit" << endl << endl;

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case '1': {
                bankSystem.openAccount();
                break;
            }
            case '2': {
                int accNum, amount;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter bill amount: ";
                cin >> amount;
                bankSystem.payBill(accNum, amount);
                break;
            }
            case '3': {
                int accNum, amount;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter amount to deposit: ";
                cin >> amount;
                bankSystem.depositMoney(accNum, amount);
                break;
            }
            case '4': {
                int accNum, amount;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter amount to withdraw: ";
                cin >> amount;
                bankSystem.withdrawMoney(accNum, amount);
                break;
            }
            case '5': {
                int accNum;
                cout << "Enter account number: ";
                cin >> accNum;
                bankSystem.viewAccountDetails(accNum);
                break;
            }
            case '6': {
                char atmChoice;
                int accNum;
                string pin, oldPin, newPin;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter PIN: ";
                cin >> pin;

                if (bankSystem.getBalance(accNum, pin) != -1) {
                    do {
                        cout << "ATM Functions:" << endl;
                        cout << "1. Validate PIN" << endl;
                        cout << "2. Withdraw Cash" << endl;
                        cout << "3. Change PIN" << endl;
                        cout << "4. Balance Inquiry" << endl;
                        cout << "5. Exit" << endl << endl;
                        cout << "Enter your choice: ";
                        cin >> atmChoice;

                        switch (atmChoice) {
                            case '1': bankSystem.validatePin(accNum, pin); break;
                            case '2': {
                                int amount;
                                cout << "Enter amount to withdraw: ";
                                cin >> amount;
                                bankSystem.withdrawMoney(accNum, amount);
                                break;
                            }
                            case '3': {
                                cout << "Enter old PIN: ";
                                cin >> oldPin;
                                cout << "Enter new PIN: ";
                                cin >> newPin;
                                bankSystem.changePin(accNum, oldPin, newPin);
                                break;
                            }
                            case '4': cout << "Balance: " << bankSystem.getBalance(accNum, pin) << endl; break;
                            case '5': break;
                            default: cout << "Wrong Choice" << endl; break;
                        }
                    } while (atmChoice != '5');
                } else {
                    cout << "Invalid account number or PIN." << endl;
                }
                break;
            }
            case '7': {
                string adminPin;
                cout << "Enter admin PIN: ";
                cin >> adminPin;
                if (bankSystem.isAdminAuthenticated(adminPin)) {
                    char adminChoice;
                    do {
                        cout << "Admin Functions:" << endl;
                        cout << "1. Pay Bill" << endl;
                        cout << "2. Open Account" << endl;
                        cout << "3. Exit" << endl << endl;
                        cout << "Enter your choice: ";
                        cin >> adminChoice;

                        switch (adminChoice) {
                            case '1': {
                                int accNum, amount;
                                cout << "Enter account number: ";
                                cin >> accNum;
                                cout << "Enter bill amount: ";
                                cin >> amount;
                                bankSystem.payBill(accNum, amount);
                                break;
                            }
                            case '2': bankSystem.openAccount(); break;
                            case '3': break;
                            default: cout << "Wrong Choice" << endl; break;
                        }
                    } while (adminChoice != '3');
                } else {
                    cout << "Invalid admin PIN." << endl;
                }
                break;
            }
            case '8':
                cout << endl << "      **EXITING** " << endl;
                return 0;
            default:
                cout << "Wrong Choice" << endl;
                break;
        }
    } while (choice != '8');

    return 0;
}

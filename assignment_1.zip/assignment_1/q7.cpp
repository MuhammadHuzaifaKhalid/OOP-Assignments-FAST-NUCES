#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// Function to get the file length (number of lines)
int MeasureFileSize(const char* filename) 
{
    ifstream file(filename);
    int length = 0;
    string line;
    while (getline(file, line)) {
        length++;
    }
    file.close();
    return length;
}

// Function to read the dictionary into an array of strings
void StoreTextInArray(const char* filename, char**& textArray, int& length) 
{
    ifstream file(filename);
    length = MeasureFileSize(filename);
    textArray = new char*[length];
    for (int i = 0; i < length; i++) {
        textArray[i] = new char[30]; // Word length max 30 let ki hai 
    }
    for (int i = 0; i < length; i++) {
        file.getline(textArray[i], 30); 
    }
    file.close();
}

//function to compare up to n characters of two strings
int CamparingStrings(const char* str1, const char* str2, unsigned int n) 
{
    for (unsigned int i = 0; i < n; ++i) {
        if (str1[i] == '\0' || str2[i] == '\0') {
            return (unsigned char)str1[i] - (unsigned char)str2[i];
        }
        if (str1[i] != str2[i]) {
            return (unsigned char)str1[i] - (unsigned char)str2[i];
        }
    }
    return 0;
}

//function to calculate the length of a string
unsigned int WordLength(const char* str) 
{
    unsigned int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

//function to copy a string
char* CopyString(char* dest, const char* src) 
{
    char* ptr = dest;
    while (*src != '\0') {
        *ptr++ = *src++;
    }
    *ptr = '\0';
    return dest;
}

// Function to search for a word in the array and store matching words in a new array
void WordSearch(char** textArray, int length, const char* userInput, char**& matchingWords, int& matchCount, int maxMatches) 
{
    matchCount = 0;
    matchingWords = new char*[maxMatches];
    for (int i = 0; i < maxMatches; i++) {
        matchingWords[i] = nullptr;
    }

    unsigned int inputLength = WordLength(userInput);

    for (int i = 0; i < length && matchCount < maxMatches; i++)
    {
        if (CamparingStrings(userInput, textArray[i], inputLength) == 0) 
        {
            unsigned int wordLength = WordLength(textArray[i]);

            matchingWords[matchCount] = new char[wordLength + 1];

            CopyString(matchingWords[matchCount], textArray[i]);

            matchCount++;
        }
    }
}

// Function to delete the original array
void deleteOriginalArray(char**& array, int length) 
{
    for (int i = 0; i < length; i++) 
    {
        delete[] array[i];
    }
    delete[] array;
    array = nullptr;
}

// Function to sort the words in the array based on length in descending order
void sortWordsByLength(char** words, int count) 
{
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (WordLength(words[i]) < WordLength(words[j])) 
            {
                char* temp = words[i];
                words[i] = words[j];
                words[j] = temp;
            }
        }
    }
}

int main() 
{
    const char* filename = "dictionary.txt";
    int length;
    char** textArray;

    StoreTextInArray(filename, textArray, length);

    cout << "Enter a word to search: ";
    char userInput[30];
    cin >> userInput;

    char** matchingWords;
    int matchCount;
    const int maxMatches = 100;

    WordSearch(textArray, length, userInput, matchingWords, matchCount, maxMatches);

    // Delete original array
    deleteOriginalArray(textArray, length);

    if (matchCount > 0) 
    {
        // Sorting call
        sortWordsByLength(matchingWords, matchCount);

        // Display the sorted words
        cout << "Words found! Sorted by length (descending):" << endl;
        for (int i = 0; i < matchCount; i++) 
        {
            cout << matchingWords[i] << endl;
            delete[] matchingWords[i]; // Free memory for each word
        }
    } else {
        cout << "No related words found." << endl;
    }

    delete[] matchingWords; // Free the array of matching words

    return 0;
}

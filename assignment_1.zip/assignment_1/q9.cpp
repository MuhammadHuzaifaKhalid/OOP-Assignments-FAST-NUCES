#include <iostream>
#include <cstring>  

using namespace std;

// Function to calculate the length of a string 
int calculateStringLength(const char* inputString) 
{
    int stringLength = 0;
    lengthCalculationStart:
    if (*(inputString + stringLength) != '\0') 
    {
        ++stringLength;
        goto lengthCalculationStart;
    }
    return stringLength;
}

//function to copy a string
void copyString(char* destination, const char* source)
{
    int index = 0;
    copyStart:
    *(destination + index) = *(source + index);
    if (*(source + index) != '\0') 
    {
        ++index;
        goto copyStart;
    }
}

// function to compare string
int compareStrings(const char* str1, const char* str2)
{
    int index = 0;
    compareStart:
    if (*(str1 + index) == *(str2 + index))
    {
        if (*(str1 + index) == '\0') 
        {
            return 0; // Strings are equal
        }
        ++index;
        goto compareStart;
    }
    if (*(str1 + index) > *(str2 + index)) 
    {
        return 1; // str1 is greater
    }
    return -1; // str2 is greater
}

// Function to generate a substring
char* generateSubstring(const char* inputString, int startIndex, int substringLength) 
{
    char* substringResult = new char[substringLength + 1];
    int currentIndex = startIndex;
    int endIndex = startIndex + substringLength;
    int substringIndex = 0;

    substringGenerationStart:
    if (currentIndex < endIndex && currentIndex < calculateStringLength(inputString)) 
    {
        *(substringResult + substringIndex) = *(inputString + currentIndex);
        ++currentIndex;
        ++substringIndex;
        goto substringGenerationStart;
    }
    *(substringResult + substringIndex) = '\0'; // Null-terminate the substring
    return substringResult;
}

// Function to print all substrings 
void displaySubstrings(const char* inputString) 
{
    int totalLength = calculateStringLength(inputString);
    for (int i = 0; i < totalLength; ++i) 
    {
        for (int len = 1; len <= totalLength - i; ++len) 
        {
            char* substring = generateSubstring(inputString, i, len);
            cout << substring << endl;
            delete[] substring; // Free dynamically allocated memory
        }
    }
}

// Function to find the lexicographically maximum 
char* findMaximumSubstring(const char* inputString) 
{
    int totalLength = calculateStringLength(inputString);
    char* maximumSubstring = new char[totalLength + 1];
    copyString(maximumSubstring, inputString);

    int currentIndex = 1;
    maxSubstringSearchStart:
    if (currentIndex < totalLength) 
    {
        char* currentSubstring = generateSubstring(inputString, currentIndex, totalLength - currentIndex);
        if (compareStrings(currentSubstring, maximumSubstring) > 0) 
        {
            copyString(maximumSubstring, currentSubstring);
        }
        delete[] currentSubstring; // Free dynamically allocated memory
        ++currentIndex;
        goto maxSubstringSearchStart;
    }
    return maximumSubstring;
}

int main() 
{
    char userInputString[50];

    cout << "Enter a string: ";
    cin.getline(userInputString, 50);

    cout << "Substrings of the input string:" << endl;
    displaySubstrings(userInputString);

    char* maximumSubstring = findMaximumSubstring(userInputString);
    cout << "Lexicographically maximum substring: " << maximumSubstring << endl;
    delete[] maximumSubstring; // Free dynamically allocated memory

    return 0;
}

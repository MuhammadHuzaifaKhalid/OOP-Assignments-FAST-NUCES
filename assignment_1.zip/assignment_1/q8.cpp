#include <iostream>

using namespace std;

// Function to get the length of a string
int StringLength(const string& str) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

// Function to concatenate a character to a string
void StringConcatenate(string& str, char c) {
    int length = StringLength(str);
    str += c;
}

// Function to compare two strings
bool StringComparison(const string& str1, const string& str2) {
    int length1 = StringLength(str1);
    int length2 = StringLength(str2);
    if (length1 != length2) return false;

    for (int i = 0; i < length1; i++) {
        if (str1[i] != str2[i]) return false;
    }
    return true;
}

// Function to check if a character is a space or punctuation
bool SpaceChecker(char c) {
    return (c == ' ' || c == '.' || c == ',' || c == ';' || c == ':' || c == '!' || c == '?');
}

// Function to split a sentence into words and count them
void WordChecker(const string& sentence, string* words, int* wordCount) {
    string word = "";
    *wordCount = 0;
    int i = 0;
    while (i < StringLength(sentence)) {
        !SpaceChecker(sentence[i]) ? StringConcatenate(word, sentence[i]) : 
        (!word.empty() ? *(words + (*wordCount)) = word, (*wordCount)++, word = "" : 0);
        i++;
    }
    !word.empty() ? *(words + (*wordCount)) = word, (*wordCount)++ : 0;
}

// Function to read a line of input from the user
void myGetLine(string& input) {
    char c;
    input = "";
    while (cin.get(c)) {
        if (c == '\n') break;
        StringConcatenate(input, c);
    }
}

// Function to check plagiarism
void checkPlagiarism(const string& sentence1, const string& sentence2, bool* isPlagiarism, double* plagiarismPercentage) {
    const int MAX_WORDS = 100; 
    string words1[MAX_WORDS], words2[MAX_WORDS];
    int count1 = 0, count2 = 0;
    
    WordChecker(sentence1, words1, &count1);
    WordChecker(sentence2, words2, &count2);
    
    int commonWords = 0;
    int i = 0;
    while (i < count2) {
        int j = 0;
        while (j < count1) {
            StringComparison(*(words2 + i), *(words1 + j)) ? commonWords++, goto nextWord : 0;
            j++;
        }
        nextWord:
        i++;
    }
    
    *plagiarismPercentage = (static_cast<double>(commonWords) / count2) * 100.0;
    *isPlagiarism = (commonWords > 0);
}

int main() {
    string sentence1, sentence2;
    bool isPlagiarism;
    double plagiarismPercentage;
    
    cout << "Enter Sentence 1: ";
    myGetLine(sentence1);
    cout << "Enter Sentence 2: ";
    myGetLine(sentence2);
    
    checkPlagiarism(sentence1, sentence2, &isPlagiarism, &plagiarismPercentage);
    
    cout << "Plagiarism Found: " << (isPlagiarism ? "true" : "false") << endl;
    cout << "Plagiarism Percentage: " << plagiarismPercentage << "%" << endl;
    
    return 0;
}

#include <iostream>
using namespace std;

void printSpaces(int count)
{
    if (count <= 0) return;
    cout << " ";
    printSpaces(count - 1);
}

void printStarsWithSpaces(int count) 
{
    if (count <= 0) return;
    cout << "* ";
    printStarsWithSpaces(count - 1);
}

// Main function to handle the entire pattern
void printPattern(int height, int current, bool isUpper) 
{
    if (isUpper) 
    {
        // Base case for the upper triangle
        if (current > height) return;

        printSpaces(height);  
        printSpaces(height - current);  
        printStarsWithSpaces(current);  
        cout << endl;

        printPattern(height, current + 1, isUpper);
    } 
    else 
    {
        // Base case for the lower triangle
        if (current >= height) return;

        printSpaces(height - current - 1);  
        printStarsWithSpaces(current + 1); 
        printSpaces((height + height - 2) - (2 * current));  
        printStarsWithSpaces(current + 1);  
        cout << endl;

        printPattern(height, current + 1, isUpper);
    }
}


 
int main() 
{ 
    int input;

    cout << "Enter size of triangle: ";
    cin >> input;
 
    printPattern(input, 1, true);  // Print upper triangle
    printPattern(input, 0, false); // Print lower triangle

    return 0; 
}

#include <iostream>
using namespace std;

const int MAX_FILES = 10;         // Maximum number of files that can be stored in memory
const int MAX_LINES = 100;        // Maximum number of lines per file
const int MAX_LINE_LENGTH = 60;   // Maximum characters per line
const int MAX_FILENAME_LENGTH = 30; // Maximum file name length

char* fileNames[MAX_FILES];       // Array to store file names
char** fileContents[MAX_FILES];   // Array to store pointers to file contents
int fileLines[MAX_FILES];         // Array to store number of lines in each file
int currentFileCount = 0;         // Counter for the number of files  

// Function prototypes
void createFile();
void viewFile();
void editFile();
void copyFile();
void deleteFile();
void listFiles();
void countWordsOrChars();
void displayFileStats();
int findFileIndex(const char* fileName);
void addFileName(const char* fileName);
void deleteFileName(int index);
void freeMemory();

// Custom function prototypes
int StringLength(const char* str);
void StringCopy(char* dest, const char* src);
void myStrncpy(char* dest, const char* src, int n);
int StringComparison(const char* str1, const char* str2);
char* myStrtok(char* str, const char* delim);
int myTolower(int c);
bool myIsalpha(int c);
void ignoreRestOfLine();
void StringConcatenate(char* dest, const char* src);
char* myStrstr(const char* haystack, const char* needle);


int main() {
    int choice;
    while (true) {
        cout << "Main Menu:\n";
        cout << "1. Create a new file.\n";
        cout << "2. View an existing file.\n";
        cout << "3. Edit an existing file.\n";
        cout << "4. Copy an existing file.\n";
        cout << "5. Delete an existing file.\n";
        cout << "6. List all files.\n";
        cout << "7. Count words or characters in a file.\n";
        cout << "8. Display file statistics.\n";
        cout << "9. Exit.\n";
        cout << "Enter your choice: ";
        cin >> choice;
        ignoreRestOfLine();

        switch (choice) {
            case 1: createFile(); break;
            case 2: viewFile(); break;
            case 3: editFile(); break;
            case 4: copyFile(); break;
            case 5: deleteFile(); break;
            case 6: listFiles(); break;
            case 7: countWordsOrChars(); break;
            case 8: displayFileStats(); break;
            case 9: freeMemory(); return 0;
            default: cout << "Invalid choice. Please try again.\n";
        }
    }
}

void createFile() {
    if (currentFileCount >= MAX_FILES) {
        cout << "Maximum file limit reached!\n";
        return;
    }

    char fileName[MAX_FILENAME_LENGTH];
    cout << "Enter the new file name: ";
    cin.getline(fileName, MAX_FILENAME_LENGTH);

    if (findFileIndex(fileName) != -1) {
        cout << "File name already exists!\n";
        return;
    }

    cout << "Enter the number of lines in the file: ";
    int numLines;
    cin >> numLines;
    ignoreRestOfLine();

    if (numLines > MAX_LINES) {
        cout << "Number of lines exceeds the maximum limit of " << MAX_LINES << ".\n";
        return;
    }

    char** lines = new char*[numLines];
    int i = 0;
    while (i < numLines) { 
        lines[i] = new char[MAX_LINE_LENGTH + 1];
        cout << "Line " << i + 1 << ": ";
        cin.getline(lines[i], MAX_LINE_LENGTH + 1);

        if (StringLength(lines[i]) > MAX_LINE_LENGTH) {
            lines[i][MAX_LINE_LENGTH] = '\0';
            ignoreRestOfLine(); // Ignore rest of the line
        }
        ++i;
    }

    fileContents[currentFileCount] = lines;
    fileLines[currentFileCount] = numLines;
    addFileName(fileName);
    currentFileCount++;
    cout << "File created successfully.\n";
}

void viewFile() {
    char fileName[MAX_FILENAME_LENGTH];
    cout << "Enter the file name to view: ";
    cin.getline(fileName, MAX_FILENAME_LENGTH);

    int index = findFileIndex(fileName);
    if (index == -1) {
        cout << "File not found!\n";
        return;
    }

    cout << "File content:\n";
    for (int i = 0; i < fileLines[index]; ++i) { 
        cout << i + 1 << ": " << fileContents[index][i] << '\n';
    }
}

void editFile() {
    char fileName[MAX_FILENAME_LENGTH];
    cout << "Enter the file name to edit: ";
    cin.getline(fileName, MAX_FILENAME_LENGTH);

    int index = findFileIndex(fileName);
    if (index == -1) {
        cout << "File not found!\n";
        return;
    }

    int choice;
    cout << "1. Edit a specific line\n";
    cout << "2. Replace a word\n";
    cout << "Enter your choice: ";
    cin >> choice;
    ignoreRestOfLine();

    if (choice == 1) {
        int lineNum;
        cout << "Enter the line number to edit: ";
        cin >> lineNum;
        ignoreRestOfLine();
        if (lineNum < 1 || lineNum > fileLines[index]) {
            cout << "Invalid line number!\n";
            return;
        }

        char newLine[MAX_LINE_LENGTH + 1];
        cout << "Enter the new content: ";
        cin.getline(newLine, MAX_LINE_LENGTH + 1);

        myStrncpy(fileContents[index][lineNum - 1], newLine, MAX_LINE_LENGTH);
        fileContents[index][lineNum - 1][MAX_LINE_LENGTH] = '\0'; // Ensure null termination
    } else if (choice == 2) {
        char oldWord[30], newWord[30];
        cout << "Enter the word to replace: ";
        cin.getline(oldWord, 30);
        cout << "Enter the new word: ";
        cin.getline(newWord, 30);

        for (int i = 0; i < fileLines[index]; ++i) { 
            char* pos = myStrstr(fileContents[index][i], oldWord);
            while (pos != nullptr) {
                char temp[MAX_LINE_LENGTH + 1];
                StringCopy(temp, pos + StringLength(oldWord));
                StringCopy(pos, newWord);
                StringConcatenate(pos, temp);
                pos = myStrstr(pos + StringLength(newWord), oldWord);
            }
        }
    } else {
        cout << "Invalid choice!\n";
    }
}

void copyFile() {
    char sourceFileName[MAX_FILENAME_LENGTH];
    cout << "Enter the source file name to copy: ";
    cin.getline(sourceFileName, MAX_FILENAME_LENGTH);

    int index = findFileIndex(sourceFileName);
    if (index == -1) {
        cout << "File not found!\n";
        return;
    }

    char destFileName[MAX_FILENAME_LENGTH];
    cout << "Enter the new file name: ";
    cin.getline(destFileName, MAX_FILENAME_LENGTH);

    if (findFileIndex(destFileName) != -1) {
        cout << "File name already exists!\n";
        return;
    }

    int numLines = fileLines[index];
    char** lines = new char*[numLines];
    for (int i = 0; i < numLines; ++i) { 
        lines[i] = new char[MAX_LINE_LENGTH + 1];
        myStrncpy(lines[i], fileContents[index][i], MAX_LINE_LENGTH);
    }

    fileContents[currentFileCount] = lines;
    fileLines[currentFileCount] = numLines;
    addFileName(destFileName);
    currentFileCount++;
    cout << "File copied successfully.\n";
}

void deleteFile() {
    char fileName[MAX_FILENAME_LENGTH];
    cout << "Enter the file name to delete: ";
    cin.getline(fileName, MAX_FILENAME_LENGTH);

    int index = findFileIndex(fileName);
    if (index == -1) {
        cout << "File not found!\n";
        return;
    }

    cout << "Are you sure you want to delete this file? (yes/no): ";
    char response[4];
    cin.getline(response, 4);

    if (StringComparison(response, "yes") == 0) { 
        for (int i = 0; i < fileLines[index]; ++i) { 
            delete[] fileContents[index][i];
        }
        delete[] fileContents[index];
        deleteFileName(index);
        currentFileCount--;
        cout << "File deleted successfully.\n";
    } else {
        cout << "File deletion canceled.\n";
    }
}

void listFiles() {
    if (currentFileCount == 0) {
        cout << "No files available.\n";
        return;
    }

    cout << "List of files:\n";
    for (int i = 0; i < currentFileCount; ++i) { 
        cout << i + 1 << ". " << fileNames[i] << '\n';
    }
}

void countWordsOrChars() {
    char fileName[MAX_FILENAME_LENGTH];
    cout << "Enter the file name: ";
    cin.getline(fileName, MAX_FILENAME_LENGTH);

    int index = findFileIndex(fileName);
    if (index == -1) {
        cout << "File not found!\n";
        return;
    }

    int choice;
    cout << "1. Count words\n";
    cout << "2. Count characters\n";
    cout << "Enter your choice: ";
    cin >> choice;
    ignoreRestOfLine();

    if (choice == 1) {
        int wordCount = 0;
        for (int i = 0; i < fileLines[index]; ++i) { 
            char* token = myStrtok(fileContents[index][i], " ");
            while (token != nullptr) {
                wordCount++;
                token = myStrtok(nullptr, " ");
            }
        }
        cout << "Total words: " << wordCount << '\n';
    } else if (choice == 2) {
        int charCount = 0;
        for (int i = 0; i < fileLines[index]; ++i) { 
            charCount += StringLength(fileContents[index][i]);
        }
        cout << "Total characters: " << charCount << '\n';
    } else {
        cout << "Invalid choice!\n";
    }
}

void displayFileStats() {
    char fileName[MAX_FILENAME_LENGTH];
    cout << "Enter the file name: ";
    cin.getline(fileName, MAX_FILENAME_LENGTH);

    int index = findFileIndex(fileName);
    if (index == -1) {
        cout << "File not found!\n";
        return;
    }

    int longestLine = 0;
    int shortestLine = MAX_LINE_LENGTH;
    int totalCharacters = 0;
    for (int i = 0; i < fileLines[index]; ++i) { 
        int lineLength = StringLength(fileContents[index][i]);
        if (lineLength > longestLine) longestLine = lineLength;
        if (lineLength < shortestLine) shortestLine = lineLength;
        totalCharacters += lineLength;
    }

    double averageLineLength = static_cast<double>(totalCharacters) / fileLines[index];
    cout << "File statistics:\n";
    cout << "Longest line length: " << longestLine << '\n';
    cout << "Shortest line length: " << shortestLine << '\n';
    cout << "Average line length: " << averageLineLength << '\n';
    cout << "Total characters: " << totalCharacters << '\n';
}

// Helper functions
int findFileIndex(const char* fileName) {
    for (int i = 0; i < currentFileCount; ++i) { 
        if (StringComparison(fileNames[i], fileName) == 0) {
            return i;
        }
    }
    return -1;
}

void addFileName(const char* fileName) {
    fileNames[currentFileCount] = new char[StringLength(fileName) + 1];
    StringCopy(fileNames[currentFileCount], fileName);
}

void deleteFileName(int index) {
    delete[] fileNames[index];
    for (int i = index; i < currentFileCount - 1; ++i) {
        fileNames[i] = fileNames[i + 1];
        fileContents[i] = fileContents[i + 1];
        fileLines[i] = fileLines[i + 1];
    }
}

void freeMemory() {
    for (int i = 0; i < currentFileCount; ++i) {
        for (int j = 0; j < fileLines[i]; ++j) {
            delete[] fileContents[i][j];
        }
        delete[] fileContents[i];
        delete[] fileNames[i];
    }
}

// Custom function implementations

int StringLength(const char* str) {
    int length = 0;
    while (str[length] != '\0') length++;
    return length;
}

void StringCopy(char* dest, const char* src) {
    while ((*dest++ = *src++));
}

void myStrncpy(char* dest, const char* src, int n) {
    while (n-- && (*dest++ = *src++));
}

int StringComparison(const char* str1, const char* str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return *(unsigned char*)str1 - *(unsigned char*)str2;
}

char* myStrtok(char* str, const char* delim) {
    static char* lastToken = nullptr;
    if (str) lastToken = str;
    if (!lastToken) return nullptr;

    char* tokenStart = lastToken;
    while (*lastToken) {
        const char* d = delim;
        while (*d) {
            if (*lastToken == *d) {
                *lastToken++ = '\0';
                return tokenStart;
            }
            d++;
        }
        lastToken++;
    }
    return (*tokenStart) ? tokenStart : nullptr;
}

int myTolower(int c) {
    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}

bool myIsalpha(int c) {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

void ignoreRestOfLine() {
    char ch;
    while (cin.get(ch) && ch != '\n');
}

char* myStrstr(const char* haystack, const char* needle) {
    if (!*needle) return (char*)haystack; // Empty needle, return haystack

    for (const char* p = haystack; *p; ++p) {
        const char* start = p;
        const char* n = needle;
        while (*start && *n && *start == *n) {
            ++start;
            ++n;
        }
        if (!*n) return (char*)p; // Full match
    }
    return nullptr;
}

void StringConcatenate(char* dest, const char* src) {
    while (*dest) dest++; // Move to the end of dest
    while (*src) {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0'; // Null-terminate the result
}

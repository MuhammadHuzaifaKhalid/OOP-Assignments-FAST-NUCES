#include <iostream>
using namespace std;

int size(const string &s, int i = 0) {
    if (s[i] == '\0' || s[i] == ' ') {
        return i;
    }
    return size(s, i + 1);
}

void convertToCaps(string &word, int i) {
    if (word[i] != '\0') {
        if (word[i] >= 'a' && word[i] <= 'z') {
            word[i] = word[i] - 'a' + 'A';
        }
        convertToCaps(word, i + 1);
    }
}

char alphadex(char ch) {
    if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'H' || ch == 'W' || ch == 'Y') {
        return '0';
    } else if (ch == 'B' || ch == 'F' || ch == 'P' || ch == 'V') {
        return '1';
    } else if (ch == 'C' || ch == 'G' || ch == 'J' || ch == 'K' || ch == 'Q' || ch == 'S' || ch == 'X' || ch == 'Z') {
        return '2';
    } else if (ch == 'D' || ch == 'T') {
        return '3';
    } else if (ch == 'M' || ch == 'N') {
        return '4';
    } else if (ch == 'L') {
        return '5';
    } else if (ch == 'R') {
        return '6';
    } else {
        return ' ';
    }
}

void convertToCode(string &word, int i) {
    if (word[i] != '\0') {
        if (i != 0) {
            word[i] = alphadex(word[i]);
        }
        convertToCode(word, i + 1);
    }
}

string removeDuplicates(const string &word, int i, char prevChar = '\0') {
    if (i == size(word)) {
        return "";
    }
    if (word[i] == prevChar) {
        return removeDuplicates(word, i + 1, prevChar);
    }
    return word[i] + removeDuplicates(word, i + 1, word[i]);
}

string removeZeros(const string &code, int i) {
    if (i == size(code)) {
        return "";
    }
    if (code[i] == '0') {
        return removeZeros(code, i + 1);
    }
    return code[i] + removeZeros(code, i + 1);
}

string adjustLength(string code, int targetLength) {
    if (size(code) >= targetLength) {
        return code.substr(0, targetLength); // Truncate if needed
    }
    return adjustLength(code + '0', targetLength);
}

string Soundex(string name) {
    convertToCaps(name, 0);
    string code = "";
    if (size(name) > 0) {
        code += name[0]; // First letter of the name
    }
    convertToCode(name, 1); // Process rest of the string to code
    code += removeDuplicates(name.substr(1), 0); // Start from the second character
    code = removeZeros(code, 0);
    code = adjustLength(code, 4);
    return code;
}

int main() {
    string name;
    cout << "Enter a name: ";
    getline(cin, name);

    string soundex = Soundex(name);
    cout << "Soundex code for " << name << ": " << soundex << endl;

    return 0;
}

#include <iostream>
#include <string>
using namespace std;

//Ye function X ko put karay at specified index
void replaceCharacter(string& str, int position, char newChar) 
{
    if (str[position] != '\0') 
    {
        if (position == 0) 
        {
            str[position] = newChar;
        } 
        else
        {
            replaceCharacter(str, position - 1, newChar);
        }
    }
}

//Recurisve cases X ke liye
void printPattern(int lineNumber, int maxLine, const string& pattern, int variant = 0) 
{
    if (lineNumber > maxLine) return;

    string output = pattern;
    switch (variant) 
    {
        case 1:
            replaceCharacter(output, 15, 'X');
            break;
        case 2:
            replaceCharacter(output, 27, 'X');
            break;
        case 3:
            replaceCharacter(output, 15, 'X');
            replaceCharacter(output, 27, 'X');
            break;
    }

    cout << output << endl;
    printPattern(lineNumber + 1, maxLine, pattern, variant);
}


void printLines(int lineNumber) {

    if (lineNumber >= 40) //End conditon, pattern stops
        return;

    if (lineNumber == 1 || lineNumber == 18 || lineNumber == 35 ) 
    {
        printPattern(lineNumber, lineNumber, "|-----------------------------------------------------------|");
    } 
    else if (lineNumber == 2 || lineNumber == 12 ||  lineNumber == 21 || lineNumber == 27) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|   |   |   |\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|");
    } 
    else if (lineNumber == 3 || lineNumber == 22 || lineNumber == 29) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\-----\\\\\\\\\\\\\\-----\\\\\\\\|---|---|---|\\\\\\-----\\\\\\\\\\\\-----\\\\\\|");
    } 
    else if (lineNumber == 4 || lineNumber == 23 || lineNumber == 30) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\     \\\\\\\\\\\\\\     \\\\\\\\|   |   |   |\\\\\\     \\\\\\\\\\\\     \\\\\\|");
    } 
    else if (lineNumber == 5 || lineNumber == 11 || lineNumber == 24 || lineNumber == 31) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\-----\\\\\\\\\\\\\\-----\\\\\\\\|---|   |---|\\\\\\-----\\\\\\\\\\\\-----\\\\\\|");
    } 
    else if (lineNumber == 6 || lineNumber == 25 || lineNumber == 26 || lineNumber == 32 || lineNumber == 34) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|   |   |   |\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|");
    } 
    else if (lineNumber == 7) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\| X |   |   |\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|");
    } 
    else if (lineNumber == 8 || lineNumber == 26 || lineNumber == 33) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|---|   |---|\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|");
    } 
    else if (lineNumber == 9) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\-----\\\\\\\\\\\\\\-----\\\\\\\\|---|   |---|\\\\\\-----\\\\\\\\\\\\-----\\\\\\|");
    } 
    else if (lineNumber == 10) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\     \\\\\\\\\\\\\\     \\\\\\\\|   |   |   |\\\\\\     \\\\\\\\\\\\     \\\\\\|");
    } 
    else if (lineNumber == 13) 
    {
        printPattern(lineNumber, lineNumber, "|   | X |   |   |   |    |           |  |   |   | X |   |   |");
    } 
    else if (lineNumber == 14) 
    {
        printPattern(lineNumber, lineNumber, "|------------------------|           |----------------------|");
    } 
    else if (lineNumber == 15) 
    {
        printPattern(lineNumber, lineNumber, "|   |                    |           |                  |   |");
    } 
    else if (lineNumber == 16) 
    {
        printPattern(lineNumber, lineNumber, "|------------------------|           |----------------------|");
    }
    else if (lineNumber == 17)
    {
        printPattern(lineNumber, lineNumber, "|   |   | X |   |   |    |           |  |   |   |   | X |   |");
    } 
    else if (lineNumber == 28) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|   |   | X |\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|");
    } 
    else if (lineNumber == 30) 
    {
        printPattern(lineNumber, lineNumber, "|\\\\\\     \\\\\\\\\\\\\\     \\\\\\\\| X |   |   |\\\\\\     \\\\\\\\\\\\     \\\\\\|");
    }

    // Recursive call for the next line
    printLines(lineNumber + 1);
}

int main() 
{
    printLines(1);
    return 0;
}
#include <iostream>
#include <string>

using namespace std;

bool isMatchingPair(const string& expr, int& idx, char expected) {
    if (idx >= expr.size()) {
        return expected == '\0';
    }

    char current = expr[idx++];
    if (current == '(' || current == '[' || current == '{') {
        char closing = (current == '(') ? ')' : ((current == '[') ? ']' : '}');
        if (!isMatchingPair(expr, idx, closing)) {
            return false;
        }
    } else if (current == ')' || current == ']' || current == '}') {
        return current == expected;
    }

    return isMatchingPair(expr, idx, expected);
}

bool isBalancedHelper(const string& expr, int idx = 0, char expected = '\0') {
    if (idx >= expr.size()) {
        return expected == '\0';
    }

    char current = expr[idx++];
    if (current == '(' || current == '[' || current == '{') {
        char closing = (current == '(') ? ')' : ((current == '[') ? ']' : '}');
        if (!isMatchingPair(expr, idx, closing)) {
            return false;
        }
        return isBalancedHelper(expr, idx, expected);
    } else if (current == ')' || current == ']' || current == '}') {
        return current == expected;
    }

    return isBalancedHelper(expr, idx, expected);
}

bool isBalanced(const string& expr) {
    return isBalancedHelper(expr);
}

int main() {
    string input;
    cout << "Enter a string to check for balanced parentheses: ";
    getline(cin, input);

    if (isBalanced(input)) {
        cout << "true" << endl;
    } else {
        cout << "false" << endl;
    }
    return 0;
}


#include <iostream>
using namespace std;

void printLine(int offset, int asteriskCount) {
    if (offset > 0) {
        cout << " ";
        printLine(offset - 1, asteriskCount);
    } else if (asteriskCount > 0) {
        cout << "*";
        printLine(offset, asteriskCount - 1);
    }
}


void drawPatternRecursive(int numBlocks, int currentBlock, int blockSize, bool forward) {
    if (currentBlock < 0 || currentBlock >= numBlocks / 2 + (numBlocks % 2)) {
        return;  
    }

    int offset = currentBlock * blockSize;

    int i = 0;

    start:
    if (i < blockSize) {
        printLine(offset, blockSize);
        cout << endl;
        ++i;
        goto start;
    }


    if (forward) {
        drawPatternRecursive(numBlocks, currentBlock + 1, blockSize, forward);
    } else {
        drawPatternRecursive(numBlocks, currentBlock - 1, blockSize, forward);
    }
}

int main() {
    int size;
    cout << "Enter size: ";
    cin >> size;

    int blockSize = 5;

    // Forward pattern
    drawPatternRecursive(size, 0, blockSize, true);

    // Middle pattern (if numBlocks is odd)
    if (size % 2 == 0) {
        int i = 0;
        
        middle_start:
        if (i < blockSize) {
            printLine((size / 2) * blockSize, blockSize);
            cout << endl;
            ++i;
            goto middle_start;
        }
    }

    // Reverse pattern
    drawPatternRecursive(size, size / 2 - 1, blockSize, false);

    return 0;
}

#include <iostream>
#include <string>
using namespace std;
const int MAX_COURSES = 100; 
const int MAX_STUDENTS_PER_COURSE = 6; 

class EnrollmentMap {
private:
    string** list;

public:

    EnrollmentMap() 
    {
        list = new string * [MAX_COURSES];
        for (int i = 0; i < MAX_COURSES; i++) {
            list[i] = new string[MAX_STUDENTS_PER_COURSE];
        }
    }

    EnrollmentMap(const EnrollmentMap& other) 
    {
        list = new string * [MAX_COURSES];
        for (int i = 0; i < MAX_COURSES; ++i) {
            list[i] = new string[MAX_STUDENTS_PER_COURSE];
            for (int j = 0; j < MAX_STUDENTS_PER_COURSE; ++j) {
                list[i][j] = other.list[i][j];
            }
        }
    }

    EnrollmentMap& operator=(const EnrollmentMap& other)
    {
        for (int i = 0; i < MAX_COURSES; i++) {
            for (int j = 0; j < MAX_STUDENTS_PER_COURSE; j++) {
                list[i][j] = other.list[i][j];
            }
        }

        return *this;
    }

    string& operator[](const string& course)
    {
        int coursenumber = 0;
        int studentnumber = 0;
        bool check = true;

        for (int i = 0; i < MAX_COURSES; i++) {
            if (list[i][0] == "") {
                for (int j = 0; j < MAX_COURSES; j++) {
                    if (list[j][0] == course) {
                        coursenumber = j;
                        check = false;
                        break;
                    }
                }
                if (check) {
                    coursenumber = i;
                    break;
                }

            }

        }

        list[coursenumber][0] = course;

        for (int i = 0; i < MAX_STUDENTS_PER_COURSE; i++) {
            if (list[coursenumber][i] == "") {
                studentnumber = i;
                break;
            }
        }

        return list[coursenumber][studentnumber];
    }

EnrollmentMap& operator+=(const string& student) {
    for (int i = 0; i < MAX_COURSES; i++) {
        for (int j = 0; j < MAX_STUDENTS_PER_COURSE; j++) {
            if (list[i][j] == "") {
                list[i][j] = student;
                return *this;  // Add student and return the current object
            }
        }
    }
    return *this;  // Return the current object
}

EnrollmentMap& operator-=(const string& student) {
    bool check = true;
    for (int i = 0; i < MAX_COURSES; i++) {
        for (int j = 0; j < MAX_STUDENTS_PER_COURSE; j++) {
            if (list[i][j] == student) {
                for (int k = j; k < MAX_STUDENTS_PER_COURSE - 1; k++) {
                    list[i][k] = list[i][k + 1];
                }
                list[i][MAX_STUDENTS_PER_COURSE - 1] = "";
                check = false;
                break;
            }
        }
        if (!check) {
            break;
        }
    }
    return *this;  // Return the current object
}


    EnrollmentMap operator+(const EnrollmentMap& other) const
    {

        int i = 0;
        while (1 > 0) {
            if (this->list[i][0] == "") {
                break;
            }
            i++;
        }
        int length1 = i;

        i = 0;
        while (1 > 0) {
            if (other.list[i][0] == "") {
                break;
            }
            i++;
        }
        int length2 = i;

        bool check = false;
        bool check2 = true;
        for (int i = 0; i < length1; i++) {
            for (int j = 0; j < length2; j++) {
                if (other.list[j][0] != "" && this->list[i][0] == other.list[j][0]) {
                    check = true;
                    for (int k = 1; k < MAX_STUDENTS_PER_COURSE; k++) {
                        for (int l = 1; l < MAX_STUDENTS_PER_COURSE; l++) {
                            if (other.list[j][l] != "" && other.list[j][l] == this->list[i][k]) {
                                check2 = false;
                            }
                        }
                        if (check2) {
                            for (int m = 0; m < MAX_STUDENTS_PER_COURSE; m++) {
                                if (other.list[j][m] == "") {
                                    other.list[j][m] = this->list[i][k];
                                    break;
                                }
                            }
                        }
                        check2 = true;
                    }
                }
            }
            if (!check) {
                for (int n = 0; n < MAX_COURSES; n++) {
                    if (other.list[n][0] == "") {
                        for (int h = 0; h < MAX_STUDENTS_PER_COURSE; h++) {
                            other.list[n][h] = this->list[i][h];
                        }
                        break;
                    }
                }
            }
            check = false;
        }

        EnrollmentMap M1;

        for (int i = 0; i < MAX_COURSES; i++) {
            for (int j = 0; j < MAX_STUDENTS_PER_COURSE; j++) {
                M1.list[i][j] = other.list[i][j];
            }
        }

        return M1;
    }

    string toString() const
{
    int length = 0;
    int i = 0;
    int* length2 = new int[MAX_COURSES];
    while (1 > 0) {
        while (1 > 0) {
            if (list[length][i] == "") {
                break;
            }
            i++;
        }
        length2[length] = i;
        i = 0;
        if (list[length][0] == "") {
            break;
        }
        length++;
    }

    string s1, s2, s3, s4, Answer;
    string* arr = new string[0];

    for (int i = 0; i < length; i++) {
        if (length2[i] > MAX_STUDENTS_PER_COURSE) {
            length2[i] = MAX_STUDENTS_PER_COURSE;
        }
    }

    for (int i = 0; i < length; i++) {
        arr = new string[length2[i] - 1];
        for (int j = 0; j < length2[i]; j++) {
            if (j == 0) {
                s1 = list[i][j];
                s2 = " : { ";
            }
            if (j > 0 && list[i][j] != "") {
                arr[j - 1] = list[i][j];
            }
            if (j == length2[i] - 1) {
                s4 = " }\n";
            }
        }
        for (int k = 0; k < length2[i] - 1; k++) {
            s3 += arr[k];
            if (k != length2[i] - 2) {
                s3 += ", ";
            }
        }
        Answer += (s1 + s2 + s3 + s4);
        s3 = "";
    }
    
    delete[] length2;
    delete[] arr;
  
    return string(Answer);
}

    ~EnrollmentMap()
    {
        for (int i = 0; i < MAX_COURSES; ++i) {
            delete[] list[i];
        }
        delete[] list;
    }
};


int main() {

	EnrollmentMap enrollments1, enrollments2, mergedEnrollments;

	enrollments1["Math 101"] = "Alice Smith";
	enrollments1["History 201"] = "Bob Johnson";
	enrollments1["Physics 101"] = "Charlie Brown";

	enrollments1["Math 101"] += "David Jones";
	enrollments1["Math 101"] += "Eva Green";

	enrollments2["Physics 101"] += "Frank White";
	enrollments2["Physics 101"] += "Grace Black";
	enrollments2["Physics 101"] += "Hank Blue";
	enrollments2["Physics 101"] += "Ivy Red";

	enrollments2["Chemistry 101"] += "Jack Gold";
	enrollments2["Chemistry 101"] += "Karen Silver";
	enrollments2["Chemistry 101"] += "Leo Bronze";
	enrollments2["Chemistry 101"] += "Mia Copper";


	cout << "enrollments1: \n" << enrollments1.toString() << endl;
    cout << "enrollments2: \n" << enrollments2.toString() << endl;
	
	mergedEnrollments = enrollments1 + enrollments2;
	cout << "Merged Enrollments: \n" << mergedEnrollments.toString() << endl;

	//enrollments1["Math 101"] -= "David Jones";
	//cout << "Updated Enrollments: " << enrollments1.toString() << endl;

	return 0;
}


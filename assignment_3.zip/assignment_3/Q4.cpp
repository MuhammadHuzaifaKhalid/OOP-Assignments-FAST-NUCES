#include <iostream>
#include <cstring>
using namespace std;

class Line {
private:
    char* text;
    int size;

public:
    Line() 
	{
		size = 0;
		text = NULL;
	}

    Line(const Line& other)
	{
		this->size = other.size;
        text = new char[size];
        
        for(int i=0;i<size;i++){
        	this->text[i] = other.text[i];
		}
    }

    Line(const char* text) {
    	int sz =0;
    	while(1>0){
    		if(text[sz] == '\0'){
    			break;
			}
			sz++;
		}
		
        this->size = sz;
        
        this->text = new char[size];
        for(int i=0;i<size;i++){
        	this->text[i] = text[i];
	    }
    }

    ~Line() {
        delete[] text;
    }

    Line& operator=(const Line& other) {
        
        delete[] text;
        size = other.size;
        text = new char[size];
        
        for(int i=0;i<size;i++){
        	this->text[i] = other.text[i];
	    }
        
        return *this;
    }

    const char* getText() const {
        return text;
    }

    void setText(const char* newText)
	{
    	int sz =0;
    	while(1>0){
    		if(newText[sz] == '\0'){
    			break;
			}
			sz++;
		}
		
        this->size = sz;
        delete[] text;
        text = new char[size];
        for(int i=0;i<size;i++){
        	this->text[i] = newText[i];
	    }
    }
};

class Page {
private:
	
    Line* lines;
    int number;

public:
    Page()
	{
    	number = 0;
    	lines = NULL;
	}

    Page(const Page& other){
    	number = other.number;
        lines = new Line[number];
        for (int i = 0; i < number; ++i) {
            lines[i] = other.lines[i];
        }
    }

    Page& operator=(const Page& other)
	 {
    	number = other.number;
    	
        delete[] lines;
        lines = new Line[number];
        
        for (int i = 0; i < number; ++i) {
            lines[i] = other.lines[i];
        }
        
        return *this;
    }

    Page& operator+=(const char* text) 
	{
        Line* temp = new Line[number + 1];
        for (int i = 0; i < number; ++i) {
            temp[i] = lines[i];
        }
        temp[number].setText(text);
        
        delete[] lines;
        lines = new Line[number+1];
        
        for(int i=0;i<number+1;i++){
        	lines[i] = temp[i];
		}
        
        number++;
        return *this;
    }

    Page& operator+=(const Line& line) {

        return (*this) += line.getText();
    }

    Line& operator[](int index) {
    	Line temp;
        temp.setText(this->lines[index].getText());

        return temp;
    }

    friend ostream& operator<<(ostream& os, const Page& page) {
        for (int i = 0; i < page.number; ++i) {
            os << page.lines[i].getText() << endl;
        }
        return os;
    }

    ~Page() {
        delete[] lines;
    }
};

class Section {
private:
    Page* pages;
    int number;

public:
    Section()
	{
		this->number = 0;
		this->pages = NULL;
	}

    Section(const Section& other)
	{
    	number = other.number;
        pages = new Page[number];
        
        for (int i = 0; i < number; ++i) {
            pages[i] = other.pages[i];
        }
    }

    Section& operator=(const Section& other) {
    	number = other.number;
    	
        delete[] pages;
        pages = new Page[number];
        
        for (int i = 0; i < number; i++) {
            pages[i] = other.pages[i];
        }
        return *this;
    }

    Section& operator+=(const Page& page) 
	{	
        Page* temp = new Page[number + 1];
        for (int i = 0; i < number; ++i) {
            temp[i] = pages[i];
        }
        
        temp[number] = page;
        
        delete[] pages;
        pages = new Page[number+1];
        
        for(int i=0;i<number+1;i++){
        	pages[i] = temp[i];
		}
        
        number++;
        return *this;
    }

    Page& operator[](int index) {
    	//*****************************************************************************
        return pages[index];
    }

    friend ostream& operator<<(ostream& os, const Section& section) {
        for (int i = 0; i < section.number; ++i) {
            os << section.pages[i] << endl;
        }
        return os;
    }

    ~Section() {
        delete[] pages;
    }
};

class Article {
private:
    Section* sections;
    int number;

public:
    Article()
	{
    	number = 0;
    	sections = NULL;
	}

    Article(const Article& other) 
	{
    	number = other.number;
        sections = new Section[number];
        
        for (int i = 0; i < number; ++i) {
            sections[i] = other.sections[i];
        }
    }

    Article& operator=(const Article& other) 
	{
		number = other.number;
		
        delete[] sections;
        sections = new Section[number];
        
        for (int i = 0; i < number; ++i) {
            sections[i] = other.sections[i];
        }
        
        return *this;
    }

    Article& operator+=(const Section& section) 
	{
        Section* temp = new Section[number + 1];
        
        for (int i = 0; i < number; ++i) {
            temp[i] = sections[i];
        }
        temp[number] = section;
        
        delete[] sections;
        sections = new Section[number +1];
        
        for(int i=0;i<number+1;i++){
        	sections[i] = temp[i];
		}
        number++;
        return *this;
    }

    Section& operator[](int index) {
        return sections[index];
    }

    friend ostream& operator<<(ostream& os, const Article& article) {
        for (int i = 0; i < article.number; ++i) {
            os << article.sections[i] << endl;
        }
        return os;
    }

    ~Article() {
        delete[] sections;
    }
};

int main() {
    Page p1, p2;

    p1 += "The quick brown fox jumps over the lazy dog. This pangram contains every letter of the alphabet, making it a popular sentence for typing practice.";
    p2 += "To be, or not to be, that is the question. Whether 'tis nobler in the mind to suffer the slings and arrows of outrageous fortune.";

    //cout << p1 << endl;
    //cout << p2 << endl;

    Section section1;
    section1 += p1;
    section1 += p2;

    //cout << section1;

    Article article;
    article += section1;

    Section section2;
    Page p5, p6;
    p5 += "We hold these truths to be self-evident, that all men are created equal, that they are endowed by their Creator with certain unalienable Rights.";
    p6 += "I have a dream that one day this nation will rise up and live out the true meaning of its creed : 'We hold these truths to be self-evident, that all men are created equal.'";

    section2 += p5;
    section2 += p6;

    article += section2;

    Line l1("Adding a fresh line to the first page of the first section.");
    Line l2("This is an additional new line.");

    article[0][0] += l1;
    article[0][0] += l2;

    cout << article;

    return 0;
}
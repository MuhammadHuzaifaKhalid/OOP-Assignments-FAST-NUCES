#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;

class Matrix
{
private:
    int rows;
    int columns;
    double **temp;

public:
    // Default constructor
    Matrix()
    {
        this->rows = 0;
        this->columns = 0;
        this->temp = NULL;
    }

    // Parameterized constructor
    Matrix(int rows, int columns)
    {
        this->rows = rows;
        this->columns = columns;

        temp = new double*[rows];
        for (int i = 0; i < rows; ++i)
        {
            temp[i] = new double[columns];
            for (int j = 0; j < columns; ++j)
            {
                temp[i][j] = 0; 
            }
        }
    }

    // Copy constructor
    Matrix(const Matrix& other)
    {
        rows = other.rows;
        columns = other.columns;
        temp = new double*[rows];
        for (int i = 0; i < rows; ++i)
        {
            temp[i] = new double[columns];
            for (int j = 0; j < columns; ++j)
            {
                temp[i][j] = other.temp[i][j];
            }
        }
    }

    // Destructor
    ~Matrix()
    {
        if (temp != NULL)
        {
            for (int i = 0; i < rows; ++i)
            {
                delete[] temp[i];
            }
            delete[] temp;
        }
    }

    Matrix& operator=(const Matrix& rhs)
    {
        if (this != &rhs) 
        {
            // Free old memory
            if (temp != NULL)
            {
                for (int i = 0; i < rows; ++i)
                {
                    delete[] temp[i];
                }
                delete[] temp;
            }

            rows = rhs.rows;
            columns = rhs.columns;

            temp = new double*[rows];
            for (int i = 0; i < rows; ++i)
            {
                temp[i] = new double[columns];
                for (int j = 0; j < columns; ++j)
                {
                    temp[i][j] = rhs.temp[i][j]; 
                }
            }
        }
        return *this;
    }

    void* operator new(size_t size)
    {
        //cout << "New operator overloading" << endl;
        return ::operator new(size);
    }

    void operator delete(void* pointer)
    {
        //cout << "Delete operator overloading " << endl;
        ::operator delete(pointer);
    }

    Matrix operator*(const Matrix& other)
    {
        if (columns != other.rows)
        {
            cout << "Error: Matrices cannot be multiplied. Incorrect dimensions" << endl;
            return Matrix(0, 0);
        }

        Matrix result(rows, other.columns);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < other.columns; ++j)
            {
                result.temp[i][j] = 0;
                for (int k = 0; k < columns; ++k)
                {
                    result.temp[i][j] += temp[i][k] * other.temp[k][j];
                }
            }
        }

        return result;
    }

    Matrix operator+(const Matrix& other)
    {
        if (rows != other.rows || columns != other.columns)
        {
            cout << "Error: Matrices cannot be added. Dimensions do not match." << endl;
            return Matrix(0, 0);
        }

        Matrix result(rows, columns);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                result.temp[i][j] = temp[i][j] + other.temp[i][j];
            }
        }

        return result;
    }

    Matrix operator-(const Matrix& other)
    {
        if (rows != other.rows || columns != other.columns)
        {
            cout << "Error: Matrices cannot be subtracted. Dimensions do not match." << endl;
            return Matrix(0, 0);
        }

        Matrix result(rows, columns);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                result.temp[i][j] = temp[i][j] - other.temp[i][j];
            }
        }

        return result;
    }

    Matrix operator*(int scalar)
    {
        Matrix result(rows, columns);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                result.temp[i][j] = temp[i][j] * scalar;
            }
        }

        return result;
    }

    Matrix operator-()
    {
        Matrix result(rows, columns);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                result.temp[i][j] = -temp[i][j];
            }
        }

        return result;
    }

    bool operator==(const Matrix& other) const
    {
        if (rows != other.rows || columns != other.columns)
        {
            return false;
        }

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                if (temp[i][j] != other.temp[i][j])
                {
                    return false;
                }
            }
        }

        return true;
    }

    bool operator!=(const Matrix& other) const
    {
        return !(*this == other);
    }

    double& operator()(int row, int column)
    {
        if (row >= 0 && row < rows && column >= 0 && column < columns)
        {
            return temp[row][column];
        }
        else
        {
            cout << "Error: Index out of bounds. Returning 0" << endl;
            static double dummy = 0;
            return dummy;
        }
    }

    friend ostream& operator<<(ostream& out, const Matrix& m)
    {
        if (m.rows == 0 || m.columns == 0)
        {
            out << "Matrix is empty." << endl;
            return out;
        }

        for (int i = 0; i < m.rows; ++i)
        {
            for (int j = 0; j < m.columns; ++j)
            {
                out << m.temp[i][j] << " ";
            }
            out << endl;
        }

        return out;
    }

    friend istream& operator>>(istream& in, Matrix& m)
    {
        cout << "Enter number of rows: ";
        in >> m.rows;
        cout << "Enter number of columns: ";
        in >> m.columns;

        if(m.rows <= 0 || m.columns <= 0)
        {
            cout << "Error: Invalid dimensions." << endl;
            exit(1);
        }
        if (m.temp != NULL)
        {
            for (int i = 0; i < m.rows; ++i)
            {
                delete[] m.temp[i];
            }
            delete[] m.temp;
        }

        m.temp = new double*[m.rows];
        for (int i = 0; i < m.rows; ++i)
        {
            m.temp[i] = new double[m.columns];
        }

        cout << "Enter matrix elements:" << endl;
        for (int i = 0; i < m.rows; ++i)
        {
            for (int j = 0; j < m.columns; ++j)
            {
                in >> m.temp[i][j];
            }
        }

        return in;
    }

    Matrix transpose() const
    {
        Matrix result(columns, rows);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                result.temp[j][i] = temp[i][j];
            }
        }

        return result;
    }

    Matrix inverse() const
    {
        if (rows != 2 || columns != 2)
        {
            cout << "Error: Inverse calculation is only implemented for 2x2 matrices." << endl;
            return Matrix(0, 0);
        }

        double det = (temp[0][0] * temp[1][1] - temp[0][1] * temp[1][0]);
        if (det == 0)
        {
            cout << "Error: Matrix is singular and cannot be inverted." << endl;
            return Matrix(0, 0);
        }

        Matrix result(2, 2);
        result.temp[0][0] = temp[1][1] / det;
        result.temp[0][1] = -temp[0][1] / det;
        result.temp[1][0] = -temp[1][0] / det;
        result.temp[1][1] = temp[0][0] / det;

        return result;
    }

    double determinant() const
    {
        if (rows != columns)
        {
            cout << "Error: Determinant calculation is only implemented for square matrices." << endl;
            return 0;
        }

        Matrix L(rows, columns);
        Matrix U(rows, columns);

        double* L_ptr = L.temp[0];
        double* U_ptr = U.temp[0];
        double* this_ptr = temp[0];

        int i = 0;
        while (i < rows)
        {
            int j = i;
            while (j < columns)
            {
                *(U_ptr + i * columns + j) = *(this_ptr + i * columns + j);
                int k = 0;
                while (k < i)
                {
                    *(U_ptr + i * columns + j) -= *(L_ptr + i * columns + k) * *(U_ptr + k * columns + j);
                    ++k;
                }
                ++j;
            }

            j = i;
            while (j < columns)
            {
                if (i == j)
                {
                    *(L_ptr + i * columns + i) = 1;
                }
                else
                {
                    *(L_ptr + j * columns + i) = *(this_ptr + j * columns + i);
                    int k = 0;
                    while (k < i)
                    {
                        *(L_ptr + j * columns + i) -= *(L_ptr + j * columns + k) * *(U_ptr + k * columns + i);
                        ++k;
                    }
                    *(L_ptr + j * columns + i) /= *(U_ptr + i * columns + i);
                }
                ++j;
            }
            ++i;
        }

        double det = 1.0;
        i = 0;
        while (i < rows)
        {
            det *= *(U_ptr + i * columns + i);
            ++i;
        }

        return det;
    }


    void saveToFile(const string& filename) const
    {
        ofstream outFile(filename);
        if (!outFile)
        {
            cout << "Error: Unable to open file for writing." << endl;
            return;
        }

        outFile << rows << " " << columns << endl;
        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                outFile << fixed << setprecision(2) << temp[i][j] << " ";
            }
            outFile << endl;
        }

        outFile.close();
    }
};

int main()
{
    Matrix* A = new Matrix(2, 2);
    Matrix* B = new Matrix(2, 2);
    Matrix* C;

    ofstream outFile("Matrix.txt");

    if (!outFile) {
        cout << "Error: Unable to open file for writing." << endl;
        return 1;
    }

    // Matrix A input and display
    cout << "Enter details for Matrix A:" << endl;
    cin >> *A;
    cout << "Matrix A:" << endl;
    cout << *A;
    outFile << "Matrix A:" << endl;
    outFile << *A << endl;

    // Matrix B input and display
    cout << "Enter details for Matrix B:" << endl;
    cin >> *B;
    cout << "Matrix B:" << endl;
    cout << *B;
    outFile << "Matrix B:" << endl;
    outFile << *B << endl;

    // Addition
    C = new Matrix(*A + *B);
    cout << "Matrix A + Matrix B:" << endl;
    cout << *C;
    outFile << "Matrix A + Matrix B:" << endl;
    outFile << *C << endl;
    delete C;

    // Subtraction
    C = new Matrix(*A - *B);
    cout << "Matrix A - Matrix B:" << endl;
    cout << *C;
    outFile << "Matrix A - Matrix B:" << endl;
    outFile << *C << endl;
    delete C;

    // Multiplication
    C = new Matrix(*A * *B);
    cout << "Matrix A * Matrix B:" << endl;
    cout << *C;
    outFile << "Matrix A * Matrix B:" << endl;
    outFile << *C << endl;
    delete C;

    // Scalar multiplication
    int scalar;
    cout << "Enter scalar value: ";
    cin >> scalar;
    Matrix D = *A * scalar;
    cout << "Matrix A * " << scalar << ":" << endl;
    cout << D;
    outFile << "Matrix A * " << scalar << ":" << endl;
    outFile << D << endl;

    // Negation
    Matrix E = -(*A);
    cout << "Negated Matrix A:" << endl;
    cout << E;
    outFile << "Negated Matrix A:" << endl;
    outFile << E << endl;

    // Transpose
    Matrix F = A->transpose();
    cout << "Transpose of Matrix A:" << endl;
    cout << F;
    outFile << "Transpose of Matrix A:" << endl;
    outFile << F << endl;

    // Inverse
    Matrix G = A->inverse(); // Assuming 2x2 matrix inverse
    cout << "Inverse of Matrix A:" << endl;
    cout << G;
    outFile << "Inverse of Matrix A:" << endl;
    outFile << G << endl;

    // Determinant

    double H = A->determinant();
    cout << "Determinant of Matrix A using LU decomposition:" << endl;
    cout << H;
    cout<<endl;
    outFile << "Determinant of Matrix A using LU decomposition:" << endl;
    outFile << H << endl;

    // Comparison
    if (*A == *B) {
        cout << "Matrix A is equal to Matrix B." << endl;
        outFile << "Matrix A is equal to Matrix B." << endl;
    } else {
        cout << "Matrix A is not equal to Matrix B." << endl;
        outFile << "Matrix A is not equal to Matrix B." << endl;
    }

    // Access and modify elements
    int row, col, value;
    cout << "Enter row and column to access element in Matrix A:" << endl;
    cout << "Enter row: ";
    cin >> row;
    cout << "Enter column: ";
    cin >> col;
    cout << "Element at (" << row << ", " << col << ") is: " << (*A)(row, col) << endl;
    outFile << "Element at (" << row << ", " << col << ") in Matrix A: " << (*A)(row, col) << endl;

    cout << "Enter row, column, and value to modify element in Matrix A:" << endl;
    cout << "Enter row: ";
    cin >> row;
    cout << "Enter column: ";
    cin >> col;
    cout << "Enter value: ";
    cin >> value;
    (*A)(row, col) = value;
    cout << "Matrix A after modification:" << endl;
    cout << *A;
    outFile << "Matrix A after modification:" << endl;
    outFile << *A << endl;

    delete A;
    delete B;

    outFile.close();

    return 0;
}

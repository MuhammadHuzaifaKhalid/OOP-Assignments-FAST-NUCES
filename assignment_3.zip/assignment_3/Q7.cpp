#include <iostream>
#include <string>

using namespace std;
 
string toBinaryString(int n)  
{
    string result = "";
    do 
    {
        result = (n % 2 == 0 ? '0' : '1') + result;
        n /= 2;
    }

    while (n > 0);
    if (result == "") result = "0";
    return result;
}

    //convert binary string to decimal
   int toDecimal(string binary) 
   {
    int result = 0;
    for (int i = 0; binary[i] != '\0'; ++i) 
    {
        result = result * 2 + (binary[i] - '0');
    }
    return result;
}

int StringLength(const string& str)
{
    int length=0;
    while (str[length] != '\0')
    {
        length++;
    }

    return length;
    
}

bool isValidBinary(const string& str) {
    int length = StringLength(str);
    for (int i = 0; i < length; ++i) {
        if (str[i] != '0' && str[i] != '1') {
            return false;  // Contains characters other than '0' and '1'
        }
    }
    return true;  // All characters are either '0' or '1'
}


class Binary {
private:
    string input_string;
    int base;

public:
    // Constructor
    Binary(string binaryStr="", int base = 2) {
        if (base > 2) {
            int base10 = 0;
            int power = 1;
            for (int i = StringLength(binaryStr) - 1; i >= 0; --i) {
                if (binaryStr[i] == '1') {
                    base10 += power;
                }
                power *= base;
            }
            this->input_string = toBinaryString(base10);
            this->base = 2;
        } else {
            this->input_string = binaryStr;
            this->base = base;
        }
    }

      Binary operator+(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        return Binary(toBinaryString(a + b));
    }
   
Binary operator-(const Binary& other) const {
    int a = toDecimal(this->input_string);
    int b = toDecimal(other.input_string);

    int difference = a - b;


    if (difference < 0) {
        return Binary("-" + toBinaryString(-difference));
    } else {
        return Binary(toBinaryString(difference));
    }
}


    // Overloading * operator for multiplication
    Binary operator*(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        return Binary(toBinaryString(a * b));
    }

    // Overloading / operator for division
    Binary operator/(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        if (b == 0) {
            cout << "Division by zero error!" << endl;
            return *this;
        }
        return Binary(toBinaryString(a / b));
    }

    // Overloading % operator for modulus
    Binary operator%(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        if (b == 0) {
            cout << "Modulus by zero error!" << endl;
            return *this;
        }
        return Binary(toBinaryString(a % b));
    }

    // Overloading | operator for OR
    Binary operator|(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        return Binary(toBinaryString(a | b));
    }

    // Overloading ^ operator for XOR
    Binary operator^(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        return Binary(toBinaryString(a ^ b));
    }

    // Overloading & operator for AND
    Binary operator&(const Binary& other) const {
        int a = toDecimal(this->input_string);
        int b = toDecimal(other.input_string);
        return Binary(toBinaryString(a & b));
    }

    // Overloading ! operator for 2's Complement
    Binary operator!() const {
    string result = "";
    int length = this->input_string.length();
    for (int i = 0; i < length; i++) {
        if (this->input_string[i] == '0') {
            result += '1';
        } else {
            result += '0';
        }
    }
    return Binary(result);
}

//1's Complement
Binary operator~() const {
    string result = "";
    int length = this->input_string.length();
    for (int i = 0; i < length; i++) {
        if (this->input_string[i] == '0') {
            result += '1';
        } else {
            result += '0';
        }
    }
    return Binary(result);
}

    // Overloading left shift operator
    Binary operator<<(int shiftAmount) const {
        int a = toDecimal(this->input_string);
        return Binary(toBinaryString(a << shiftAmount));
    }

    // Overloading right shift operator
    Binary operator>>(int shiftAmount) const {
        int a = toDecimal(this->input_string);
        return Binary(toBinaryString(a >> shiftAmount));
    }

   friend istream& operator>>(istream& input, Binary& bin) {
    string inputStr;
    int base;
    cout << "Enter a number in Binary or Decimal: ";
    input >> inputStr;
    cout << "Enter the base (2 for Binary, 10 for Decimal): ";
    input >> base;
    
    if (base <= 0) {
        cout << "Wrong base input" << endl;
        exit(0);
    }
    
    if (base == 2) {
        if (!isValidBinary(inputStr)) {
            cout << "Invalid binary input. Only '0' and '1' are allowed." << endl;
            exit(0);
        }
        // Input is a valid binary string
        bin.input_string = inputStr;
    } else {
        // Input is a decimal integer
        int decimalValue = 0;
        int sign = 1;
        size_t startIndex = 0;

        // Check if the decimal number is negative
        if (inputStr[0] == '-') {
            sign = -1;
            startIndex = 1;
        }

        // Convert each character to integer
        for (size_t i = startIndex; i < StringLength(inputStr); ++i) {
            if (inputStr[i] < '0' || inputStr[i] > '9') {
                cout << "Invalid decimal input. Only digits are allowed." << endl;
                exit(0);
            }
            decimalValue = decimalValue * 10 + (inputStr[i] - '0');
        }

        decimalValue *= sign;  // Apply the sign

        bin.input_string = toBinaryString(decimalValue);
    }
    return input;
}

    // Overloading output operator
    friend ostream& operator<<(ostream& output, const Binary& other) {
        output << "Binary: " << other.input_string << ", Integer: " << toDecimal(other.input_string);
        return output;
    }
};

int main() {
    Binary b1;
    Binary b2;
    cout<<""<<endl;
    cin>>b1;
    cout<<""<<endl;
    cin>>b2;
    

    //arithmetic operators
    Binary addResult = b1 + b2;
    Binary subResult = b1 - b2;
    Binary mulResult = b1 * b2;
    Binary divResult = b1 / b2;
    Binary modResult = b1 % b2;

    cout << "Addition: " << addResult << endl;
    cout << "Subtraction: " << subResult << endl;
    cout << "Multiplication: " << mulResult << endl;
    cout << "Division: " << divResult << endl;
    cout << "Modulus: " << modResult << endl;

    //bitwise operators
    Binary orResult = b1 | b2;
    Binary xorResult = b1 ^ b2;
    Binary andResult = b1 & b2;
    Binary notResult = !b1;
    Binary complementResult = ~b1;
    Binary leftShiftResult = b1 << 2;
    Binary rightShiftResult = b1 >> 2;

    cout << "OR: " << orResult << endl;
    cout << "XOR: " << xorResult << endl;
    cout << "AND: " << andResult << endl;
    cout << "NOT: " << notResult << endl;
    cout << "1's Complement of number 1: " << complementResult << endl;
    cout << "Left Shift of number 1: " << leftShiftResult << endl;
    cout << "Right Shift of number 1: " << rightShiftResult << endl;

    return 0;
}

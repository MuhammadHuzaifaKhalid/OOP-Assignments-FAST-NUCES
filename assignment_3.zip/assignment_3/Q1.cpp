#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

// Helper function to convert string to double
double stringToDouble(const string& str) {
    double result = 0.0;
    int i = 0;
    bool negative = false;

    if (str[i] == '-') {
        negative = true;
        ++i;
    }

    // Convert integer part
    while (i < str.length() && str[i] >= '0' && str[i] <= '9') {
        result = result * 10 + (str[i] - '0');
        ++i;
    }

    // Convert fractional 
    if (i < str.length() && str[i] == '.') {
        ++i;
        double fraction = 1.0;
        while (i < str.length() && str[i] >= '0' && str[i] <= '9') {
            fraction /= 10;
            result += (str[i] - '0') * fraction;
            ++i;
        }
    }

    return negative ? -result : result;
}

// Helper function to convert string to integer
int stringToInt(const string& str) {
    int result = 0;
    int i = 0;
    bool negative = false;

    // Handle negative numbers
    if (str[i] == '-') {
        negative = true;
        ++i;
    }

    // Convert number
    while (i < str.length() && str[i] >= '0' && str[i] <= '9') {
        result = result * 10 + (str[i] - '0');
        ++i;
    }

    return negative ? -result : result;
}

class Car {
private:
    int index;
    string dateCrawled;
    string name;
    string sellerType;
    string offerType;
    double price;
    string abTesting;
    string vehicleType;
    int yearOfRegistration;
    string gearboxType;
    int powerOutput;
    string model;
    int kilometersDriven;
    int monthOfRegistration;
    string fuelType;
    string brandName;
    string notRepairedDamage;
    string dateCreated;
    int nrofpictures;
    string postalcode;
    string lastSeen;

public:
    // Default Constructor
    Car() {
        index = 0;
        dateCrawled = "";
        name = "";
        sellerType = "";
        offerType = "";
        price = 0.0;
        abTesting = "";
        vehicleType = "";
        yearOfRegistration = 0;
        gearboxType = "";
        powerOutput = 0;
        model = "";
        kilometersDriven = 0;
        monthOfRegistration = 0;
        fuelType = "";
        brandName = "";
        notRepairedDamage = "";
        dateCreated = "";
        nrofpictures = 0;
        postalcode = "";
        lastSeen = "";
    }

    // Parameterized Constructor
    Car(int i, const string& dateCrawled, const string& name, const string& sellerType, const string& offerType, double price, const string& abTesting, const string& vehicleType, int yearOfRegistration, const string& gearboxType, int powerOutput, const string& model, int kilometersDriven, int monthOfRegistration, const string& fuelType, const string& brandName, const string& notRepairedDamage, const string& dateCreated, int nrofpictures, const string& postalcode, const string& lastSeen) 
    {
        index = i;
        this->dateCrawled = dateCrawled;
        this->name = name;
        this->sellerType = sellerType;
        this->offerType = offerType;
        this->price = price;
        this->abTesting = abTesting;
        this->vehicleType = vehicleType;
        this->yearOfRegistration = yearOfRegistration;
        this->gearboxType = gearboxType;
        this->powerOutput = powerOutput;
        this->model = model;
        this->kilometersDriven = kilometersDriven;
        this->monthOfRegistration = monthOfRegistration;
        this->fuelType = fuelType;
        this->brandName = brandName;
        this->notRepairedDamage = notRepairedDamage;
        this->dateCreated = dateCreated;
        this->nrofpictures = nrofpictures;
        this->postalcode = postalcode;
        this->lastSeen = lastSeen;
    }

    Car operator+(const Car& other) const 
    {
        Car temp;

        // Adding integer and float members
        temp.index = this->index + other.index;
        temp.price = this->price + other.price;
        temp.yearOfRegistration = this->yearOfRegistration + other.yearOfRegistration;
        temp.powerOutput = this->powerOutput + other.powerOutput;
        temp.kilometersDriven = this->kilometersDriven + other.kilometersDriven;
        temp.monthOfRegistration = this->monthOfRegistration + other.monthOfRegistration;
        temp.nrofpictures = this->nrofpictures + other.nrofpictures;

        // Assign string members from the first car
        temp.dateCrawled = this->dateCrawled;
        temp.name = this->name;
        temp.sellerType = this->sellerType;
        temp.offerType = this->offerType;
        temp.abTesting = this->abTesting;
        temp.vehicleType = this->vehicleType;
        temp.gearboxType = this->gearboxType;
        temp.model = this->model;
        temp.fuelType = this->fuelType;
        temp.brandName = this->brandName;
        temp.notRepairedDamage = this->notRepairedDamage;
        temp.dateCreated = this->dateCreated;
        temp.postalcode = this->postalcode;
        temp.lastSeen = this->lastSeen;

        return temp;
    }

     Car& operator+=(const Car& other) {
        // Add integer and float members
        this->index += other.index;
        this->price += other.price;
        this->yearOfRegistration += other.yearOfRegistration;
        this->powerOutput += other.powerOutput;
        this->kilometersDriven += other.kilometersDriven;
        this->monthOfRegistration += other.monthOfRegistration;
        this->nrofpictures += other.nrofpictures;

        return *this;
    }

    double operator-(const Car& other) const 
    {
        return this->price - other.price;
    }
    
    Car& operator-=(const Car& other) {
        // Subtract integer and float members
        this->index -= other.index;
        this->price -= other.price;
        this->yearOfRegistration -= other.yearOfRegistration;
        this->powerOutput -= other.powerOutput;
        this->kilometersDriven -= other.kilometersDriven;
        this->monthOfRegistration -= other.monthOfRegistration;
        this->nrofpictures -= other.nrofpictures;

        return *this;
    }

    bool operator==(const Car& other) const 
    {
        return (this->index == other.index && this->dateCrawled == other.dateCrawled && this->name == other.name && this->sellerType == other.sellerType && this->offerType == other.offerType && this->price == other.price && this->abTesting == other.abTesting && this->vehicleType == other.vehicleType && this->yearOfRegistration == other.yearOfRegistration && this->gearboxType == other.gearboxType && this->powerOutput == other.powerOutput && this->model == other.model && this->kilometersDriven == other.kilometersDriven && this->monthOfRegistration == other.monthOfRegistration && this->fuelType == other.fuelType && this->brandName == other.brandName && this->notRepairedDamage == other.notRepairedDamage && this->dateCreated == other.dateCreated && this->nrofpictures == other.nrofpictures && this->postalcode == other.postalcode && this->lastSeen == other.lastSeen);
    }

    bool operator>(const Car& other) const 
    {
        return (this->price > other.price) || (this->powerOutput > other.powerOutput) || (this->kilometersDriven > other.kilometersDriven);
    }

    bool operator<(const Car& other) const 
    {
        return (this->price < other.price) && (this->powerOutput < other.powerOutput) && (this->kilometersDriven < other.kilometersDriven);
    }

    bool operator>=(const Car& other) const 
    {
        return (this->price >= other.price) && (this->powerOutput >= other.powerOutput) && (this->kilometersDriven >= other.kilometersDriven);
    }

    bool operator<=(const Car& other) const 
    {
        return (this->price <= other.price) && (this->powerOutput <= other.powerOutput) && (this->kilometersDriven <= other.kilometersDriven);
    }

    bool operator!=(const Car& other) const 
    {
        return (this->price != other.price) && (this->powerOutput != other.powerOutput) && (this->kilometersDriven != other.kilometersDriven);
    }

    // Overloading >> operator to read car details from input stream
    friend istream& operator>>(istream& input, Car& car) {
        string line;
        getline(input, line);

        stringstream s(line);

        // Read each field
        string indexStr;
        getline(s, indexStr, ',');
        car.index = stringToInt(indexStr);

        getline(s, car.dateCrawled, ',');
        getline(s, car.name, ',');
        getline(s, car.sellerType, ',');
        getline(s, car.offerType, ',');

        string priceStr;
        getline(s, priceStr, ',');
        car.price = stringToDouble(priceStr);

        getline(s, car.abTesting, ',');
        getline(s, car.vehicleType, ',');

        string yearStr;
        getline(s, yearStr, ',');
        car.yearOfRegistration = stringToInt(yearStr);

        getline(s, car.gearboxType, ',');

        string powerStr;
        getline(s, powerStr, ',');
        car.powerOutput = stringToInt(powerStr);

        getline(s, car.model, ',');

        string kilometersStr;
        getline(s, kilometersStr, ',');
        car.kilometersDriven = stringToInt(kilometersStr);

        string monthStr;
        getline(s, monthStr, ',');
        car.monthOfRegistration = stringToInt(monthStr);

        getline(s, car.fuelType, ',');
        getline(s, car.brandName, ',');
        getline(s, car.notRepairedDamage, ',');
        getline(s, car.dateCreated, ',');

        string nrofpicturesStr;
        getline(s, nrofpicturesStr, ',');
        car.nrofpictures = stringToInt(nrofpicturesStr);

        getline(s, car.postalcode, ',');
        getline(s, car.lastSeen, ',');

        return input;
    }

    // Overloading << operator to display car details
    friend ostream& operator<<(ostream& output, const Car& car) {
        output << "Index: " << car.index << "\n"
               << "Date Crawled: " << car.dateCrawled << "\n"
               << "Name: " << car.name << "\n"
               << "Seller Type: " << car.sellerType << "\n"
               << "Offer Type: " << car.offerType << "\n"
               << "Price: " << car.price << "\n"
               << "A/B Testing: " << car.abTesting << "\n"
               << "Vehicle Type: " << car.vehicleType << "\n"
               << "Year of Registration: " << car.yearOfRegistration << "\n"
               << "Gearbox Type: " << car.gearboxType << "\n"
               << "Power Output: " << car.powerOutput << "\n"
               << "Model: " << car.model << "\n"
               << "Kilometers Driven: " << car.kilometersDriven << "\n"
               << "Month of Registration: " << car.monthOfRegistration << "\n"
               << "Fuel Type: " << car.fuelType << "\n"
               << "Brand Name: " << car.brandName << "\n"
               << "Not Repaired Damage: " << car.notRepairedDamage << "\n"
               << "Date Created: " << car.dateCreated << "\n"
               << "Number of Pictures: " << car.nrofpictures << "\n"
               << "Postal Code: " << car.postalcode << "\n"
               << "Last Seen: " << car.lastSeen << "\n";
        return output;
    }
};

void readCSV(const string& filename, Car* cars, int numLines) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    string line;
    // Skip the header line
    getline(file, line);

    for (int i = 0; i < numLines && getline(file, line); ++i) {
        stringstream s(line);
        s >> cars[i];
    }

    file.close();
}

int main() {
    int num;
    cout << "Enter the number of lines to read from the CSV file: ";
    cin >> num;
    if(num <=0)
    {
        cout<<"Invalid Input"<<endl;
        return 0;
    }
    cin.ignore(); 
    cout<<"You have loaded "<<num<<" cars info from file"<<endl<<endl; 

    Car* cars = new Car[num];
    readCSV("autos.csv", cars, num);

    int a,b;
    cout<<"Enter car 1 index for + operator overload: ";
    cin>>a;
    cout<<"Enter car 2 index for + operator overload: ";
    cin>>b;

    if(a>num || b>num || a<0 || b<0)
    {
        cout<<"Invalid index for + operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 + Car 2:"<<endl;
        Car temp = cars[a] + cars[b];
        cout<<temp<<endl;
    }

    int c,d;
    cout<<"Enter car 1 index for += operator overload: ";
    cin>>c;
    cout<<"Enter car 2 index for += operator overload: ";
    cin>>d;

    if(c>num || d>num || c<0 || d<0)
    {
        cout<<"Invalid index for += operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 += Car 2:"<<endl;
        cars[c] += cars[d];
        cout<<cars[c]<<endl;
    }

    int e,f;
    cout<<"Enter car 1 index for - operator overload: ";
    cin>>e;
    cout<<"Enter car 2 index for - operator overload: ";
    cin>>f;

    if(e>num || f>num || e<0 || f<0)
    {
        cout<<"Invalid index for - operator"<<endl;
    }
    else
    {
        cout<<endl<<"Sale Price Usinf - operator overload (Negative be hoskati hai):"<<endl;
        cout<<cars[e] - cars[f]<<endl;
    }

    int g,h;
    cout<<"Enter car 1 index for -= operator overload: ";
    cin>>g;
    cout<<"Enter car 2 index for -= operator overload: ";
    cin>>h;

    if(g>num || h>num || g<0 || h<0)
    {
        cout<<"Invalid index for -= operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 -= Car 2:"<<endl;
        cars[g] -= cars[h];
        cout<<cars[g]<<endl;
    }

    int i,j;
    cout<<"Enter car 1 index for == operator overload: ";
    cin>>i;
    cout<<"Enter car 2 index for == operator overload: ";
    cin>>j;

    if(g>num || h>num || g<0 || h<0)
    {
        cout<<"Invalid index for == operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 == Car 2:"<<endl;
        if(cars[i] == cars[j])
        {
            cout<<"True"<<endl;
        }
        else cout<<"False"<<endl;
    }

    int k,l;
    cout<<"Enter car 1 index for > operator overload: ";
    cin>>k;
    cout<<"Enter car 2 index for > operator overload: ";
    cin>>l;

    if(k>num || l>num || k<0 || l<0)
    {
        cout<<"Invalid index for > operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 > Car 2:"<<endl;
        if(cars[k] > cars[l])
        {
            cout<<"True"<<endl;
        }
         else cout<<"False"<<endl;
    }

    int m,n;
    cout<<"Enter car 1 index for < operator overload: ";
    cin>>m;
    cout<<"Enter car 2 index for < operator overload: ";
    cin>>n;

    if(m>num || n>num || m<0 || n<0)
    {
        cout<<"Invalid index for < operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 < Car 2:"<<endl;
        if(cars[m] < cars[n])
        {
            cout<<"True"<<endl;
        }
         else cout<<"False"<<endl;
    }

    int o,p;
    cout<<"Enter car 1 index for >= operator overload: ";
    cin>>o;
    cout<<"Enter car 2 index for >= operator overload: ";
    cin>>p;

    if(o>num || p>num || o<0 || p<0)
    {
        cout<<"Invalid index for >= operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 >= Car 2:"<<endl;
        if(cars[o] >= cars[p])
        {
            cout<<"True"<<endl;
        }

        else cout<<"False"<<endl;
    }

    int q,r;
    cout<<"Enter car 1 index for <= operator overload: ";
    cin>>q;
    cout<<"Enter car 2 index for <= operator overload: ";
    cin>>r;

    if(q>num || r>num || q<0 || r<0)
    {
        cout<<"Invalid index for <= operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 <= Car 2:"<<endl;
        if(cars[q] >= cars[r])
        {
            cout<<"True"<<endl;
        }

        else cout<<"False"<<endl;
    }

    int s,t;
    cout<<"Enter car 1 index for != operator overload: ";
    cin>>s;
    cout<<"Enter car 2 index for != operator overload: ";
    cin>>t;

    if(s>num || t>num || s<0 || t<0)
    {
        cout<<"Invalid index for != operator"<<endl;
    }
    else
    {
        cout<<endl<<"Car 1 != Car 2:"<<endl;
        if(cars[s] != cars[t])
        {
            cout<<"True"<<endl;
        }

        else cout<<"False"<<endl;
    }

    // Display cars
    /* for (int i = 0; i < num; ++i) {
        cout << cars[i] << "\n";
    } */

    delete[] cars;
    return 0;
}

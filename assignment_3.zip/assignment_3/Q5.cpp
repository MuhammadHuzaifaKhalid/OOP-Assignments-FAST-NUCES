#include <iostream>
using namespace std;
class DynamicArray {
private:

    int* Array;
    int sizes;

public:

    DynamicArray(int size) 
    {
        this->sizes = size;
        Array = new int[this->sizes];
    }

    DynamicArray(const DynamicArray& other) 
    {
        this->sizes = other.sizes;
        Array = new int[sizes];
        for (int i = 0; i < sizes; i++) {
            Array[i] = other.Array[i];
        }
    }
  
    int& operator[](int index)
    {
        return Array[index];
    }

    const int& operator[](int index) const 
    {
        return Array[index];
    }

    DynamicArray& operator=(const DynamicArray& other)
    {
        delete[] this->Array;
        Array = new int[other.sizes];
        this->sizes = other.sizes;

        for (int i = 0; i < other.sizes; i++) {
            this->Array[i] = other.Array[i];
        }
     
        return *this;
    }

    DynamicArray& operator=(DynamicArray&& other) 
    {
        delete[] this->Array;
        Array = new int[other.sizes];
        this->sizes = other.sizes;

        for (int i = 0; i < other.sizes; i++) {
            this->Array[i] = other.Array[i];
        }

        delete[] other.Array;
        other.Array = nullptr;
        other.sizes = 0;

        return *this;
    }

    DynamicArray& operator+=(const DynamicArray& other) 
    {
        if (this->sizes > other.sizes) {
            for (int i = 0; i < other.sizes; i++) {
                this->Array[i] += other.Array[i];
            }
        }

        else if(other.sizes > this->sizes)
        {
            for (int i = 0; i < this->sizes; i++) {
                other.Array[i] += this->Array[i];
            }
            
            delete[] this->Array;
            this->Array = new int[other.sizes];

            for (int i = 0; i < other.sizes; i++) {
                this->Array[i] = other.Array[i];
            }

            this->sizes = other.sizes;
        }

        else if (this->sizes == other.sizes) {
            for (int i = 0; i < sizes; i++) {
                Array[i] += other.Array[i];
            }
        }

        return *this;
    }

    DynamicArray operator+(const DynamicArray& other) const 
    {
        if (this->sizes > other.sizes)
        {
            for (int i = 0; i < other.sizes; i++) {
                this->Array[i] += other.Array[i];
            }

            return *this;
        }

        else if (other.sizes > this->sizes)
        {
            for (int i = 0; i < this->sizes; i++) {
                other.Array[i] += this->Array[i];
            }

            return other;
        }

        else if (this->sizes == other.sizes)
        {
            for (int i = 0; i < sizes; i++) {
                Array[i] += other.Array[i];
            }
     
            return *this;
        }
    }

    friend ostream& operator<<(std::ostream& os, const DynamicArray& arr)
    {
        os << "{ ";
        for (int i = 0; i < arr.sizes; i++) {
            os << arr.Array[i];
            os << " ";
        }
        os << "}";

        return os;
    }

    int size() const
    {
        return sizes;
    }

    ~DynamicArray()
    {
        delete[] Array;
    }
};

int main() {

	DynamicArray inventory1(5); 
	DynamicArray inventory2(10); 
	
	
	for (int i = 0; i < 5; i++) {
		inventory1[i] = i * 10; 
	}

	for (int i = 0; i < 10; i++) {
		inventory2[i] = i * 5;
	}
	
    cout<<endl;
	cout << inventory1 << endl;
    cout<<endl;
	cout << inventory2 << endl;

	inventory1 += inventory2; 
	
    cout<<endl;
	cout << inventory1 << endl;

	DynamicArray totalInventory = inventory1 + inventory2; 	
	
    cout<<endl;
	cout << totalInventory << endl;
	
    cout<<endl;
	cout << "Total products: " << totalInventory.size() << endl;

	return 0;
}
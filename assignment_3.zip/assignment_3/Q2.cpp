#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;

    int gcd(int a, int b) const 
    {
        return b == 0 ? a : gcd(b, a % b);
    }

    void fraction_cutting() 
    {
        if (numerator == 0) 
        {
            denominator = 1;
        } 
        else
        {
            int common_divisor = gcd(numerator, denominator);
            numerator /= common_divisor;
            denominator /= common_divisor;
        }
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    Rational()
    {
        this->numerator = 0;
        this->denominator = 1;
    }

    Rational(int n, int d)  
    {
        numerator = n;
        denominator = d;
        if (d == 0) {
            cout << "Error: Denominator cannot be zero. Mein 1 default set karun ga" << endl;
            //exit(1);
            denominator = 1;
        }
        fraction_cutting();
    }

    Rational(const Rational& temp)
    {
        numerator = temp.numerator;
        denominator = temp.denominator;
        fraction_cutting();
    }

    ~Rational() {}

    Rational operator+(const Rational& temp) const {
        return Rational(numerator * temp.denominator + temp.numerator * denominator,
                        denominator * temp.denominator);
    }

    Rational operator-(const Rational& temp) const {
        return Rational(numerator * temp.denominator - temp.numerator * denominator,
                        denominator * temp.denominator);
    }

    Rational operator*(const Rational& temp) const {
        return Rational(numerator * temp.numerator, denominator * temp.denominator);
    }

    Rational operator/(const Rational& temp) const {
        if (temp.numerator == 0) {
            cout << "Error: Division by zero." << endl;
            return Rational();
        }
        return Rational(numerator * temp.denominator, denominator * temp.numerator);
    }

    bool operator==(const Rational& temp) const {
        return (numerator == temp.numerator) && (denominator == temp.denominator);
    }

    bool operator!=(const Rational& temp) const {
        return !(*this == temp);
    }

    friend ostream& operator<<(ostream& output, const Rational& rational) {
        output << rational.numerator;
        if (rational.denominator != 1) {
            output << '/' << rational.denominator;
        }
        return output;
    }

    friend istream& operator>>(istream& input, Rational& rational) {
        cout << "Enter numerator: ";
        input >> rational.numerator;

        cout << "Enter denominator: ";
        input >> rational.denominator;

        if (rational.denominator == 0) {
            cout << "Error: Denominator cannot be zero. 1 default set ho jaye gi" << endl;
            rational.denominator = 1;
        }

        rational.fraction_cutting();
        return input;
    }
};

int main() {
    Rational a, b;
    
    cout << "Enter first fraction:" << endl;
    cin >> a;
    
    cout << "Enter second fraction:" << endl;
    cin >> b;

    cout << "First Fraction: " << a << endl;
    cout << "Second Fraction: " << b << endl;

    Rational sum = a + b;
    cout << "Sum: " << sum << endl;
    
    Rational difference = a - b;
    cout << "Difference: " << difference << endl;

    Rational product = a * b;
    cout << "Product: " << product << endl;

    Rational quotient = a / b;
    cout << "Quotient: " << quotient << endl;

    if (a != b) {
        cout << "The fractions are equal." << endl;
    } else {
        cout << "The fractions are not equal." << endl;
    }

    return 0;
}
